
	<!-- 前台bootstrap页脚 -->
	<div class="container" id="footer">
		<div class="row">
			<div class="col-lg-12">
				<ul class="list-unstyled">
				<li class="pull-right"><a href="#top">返回顶部</a></li>
				</ul>
				<p>&copy; {{ date('Y') }} 由  <a href="http://www.zealer.work">zealer</a>  所驱动的博客,  本博客使用 <a href="http://www.zealer.work/">Bootstrap</a> 构建，更多第三方主题可参阅  <a href="http://www.zealer.work" target="_blank">Bootswatch</a>  .</p>
			</div>
		</div>
	</div>

