{{-- starter.blade.php --}}

@extends('layout._back')

@section('content-header')
@parent
          <h1>
            起步
            <small></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> 主页</a></li>
            <li class="active">起步</li>
          </ol>
@stop


