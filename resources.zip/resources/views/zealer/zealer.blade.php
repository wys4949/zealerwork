<!DOCTYPE html>
<!-- saved from url=(0022)http://www.zealer.com/ -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<title>ZEALER - 科技生活方式第一站</title> 
<meta name="keywords" content="手机评测，数码产品测评，科技产品测评">
<meta name="description" content="ZEALER 是中国权威的科技电子产品测评网站，由王自如等科技达人傾力打造，测评内容涉及手机的 Android，iOS，WP 等周边数码产品，致力于还原科技本质，为用户提供最专业的点评和最客观的资讯">
<meta property="qc:admins" content="271622326062514526375">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
 
<link href="{{asset('zealer_files/libs_98e9c.css')}}" rel="stylesheet" type="text/css">
<link href="{{asset('zealer_files/global_4eae3726c8.css')}}" rel="stylesheet" type="text/css">
<link href="{{asset('zealer_files/page_d849feee87.css')}}" rel="stylesheet" type="text/css">

<link rel="icon" href="http://www.zealer.com/favicon.ico">
<script src="{{asset('zealer_files/push.js')}}"></script><script async="" src="{{asset('zealer_files/analytics.js')}}"></script><script src="{{asset('zealer_files/hm.js')}}"></script><script>
var STATIC_HOST = 'http://static.zealer.com/';
var STAT_HOST = 'http://stat.wangziru.com/';
var WWW_HOST = 'http://www.zealer.com/';
</script>
<script>
//移动设备判断
var isMobile = {
    Android: function() {
        return navigator.userAgent.match(/Android/i) ? true : false;
    },
    BlackBerry: function() {
        return navigator.userAgent.match(/BlackBerry/i) ? true : false;
    },
    iOS: function() {
        return navigator.userAgent.match(/iPhone|iPad|iPod/i) ? true : false;
    },
    Windows: function() {
        return navigator.userAgent.match(/IEMobile/i) ? true : false;
    },
Phone: function() {
return navigator.userAgent.match(/Mobile/i) ? true : false;
},
    any: function() {
        return (isMobile.Android() || isMobile.BlackBerry() || isMobile.Windows() || isMobile.Phone());
    }
};

function isIE () {
var myNav = navigator.userAgent.toLowerCase();
return (myNav.indexOf('msie') != -1) ? parseInt(myNav.split('msie')[1]) : false;
};

</script>
    <link rel="stylesheet" href="{{asset('zealer_files/libs_98e9c.css')}}">
</head>
<body>
<div class="global_cover"></div>

<div class="global_header bigHead">
<div class="header_inner clear">

<div class="account_wrap">
<div class="header_account clear">
<ul class="account_nav clear">
    @foreach($title as $t)
        @if($t->tit_id<=3)
        <li><a class="" href="{{$t->tit_url}}">{{$t->tit_name}}</a></li>
        @else
            <li><a class="" href="{{$t->tit_url}}" target="_blank">{{$t->tit_name}}</a></li>
            @endif

    @endforeach

</ul>
<div class="inner_account">
<a href="http://www.zealer.com/search" target="_blank" class="account_search index_icons"></a>
<a href="http://www.zealer.com/message?type=discuss" target="_blank" class="account_message">通知
<span class="message_num"></span>
</a>
<a href="http://www.zealer.com/message?type=inbox" target="_blank" class="account_letter">私信
<span class="letter_num"></span>
</a>
<span class="account_user clear">
<a class="img_link clear" href="http://www.zealer.com/personal">
<img class="user_img" src="{{asset('zealer_files/mb_pic30.gif')}}" alt="会员头像">
</a>
<span class="user_active bigHead">
<a href="http://www.zealer.com/personal" class="active_name" rel="nofollow"></a>
<a href="http://www.zealer.com/user/logout" rel="nofollow">退出</a>
</span>
</span>
<div class="account_list message_list clear"></div>
<div class="account_list sms_list clear">
</div>
</div>
<div class="inner_login" style="">
<a class="login_in global_gaNode" href="http://www.zealer.com/login/?from=index&amp;redirect=http%3A%2F%2Fwww.zealer.com%2F" data-galable="home_header_login">登录</a>
<a class="logoutCss global_gaNode" href="http://www.zealer.com/reg?from=Index&amp;redirect=http%3A%2F%2Fwww.zealer.com%2F" data-galable="home_header_reg">注册</a>
</div>
</div>
</div>

<div class="nav_wrap">
<a class="inner_logo index_icons global_gaNode" href="http://www.zealer.com/" data-galable="home_header_logo"></a>
<ul class="inner_nav">
    @foreach($titles as $ti)
        @if($ti->tit_id<=3)
            <li><a class="global_gaNode" href="{{$ti->tit_url}}" data-galable="home_header_nav_index">{{$ti->tit_name}}</a></li>
            @elseif($ti->tit_id<=6)

            <li><a class="global_gaNode" href="{{$ti->tit_url}}" target="_blank" data-galable="home_header_nav_plus">{{$ti->tit_name}}</a></li>

            @else

            <li><a href="{{$ti->tit_url}}" class="header_contactUs global_gaNode" target="_blank" rel="nofollow" data-galable="home_header_nav_contact">{{$ti->tit_name}}</a></li>

            @endif
    @endforeach

<li class="app_download">APP下载
<div class="app_area">
<div class="area_wrap clear">
<div class="area_left">
<div class="qr_wrap">
<a href="http://www.zealer.com/assets/ZEALER.apk" target="_blank">立即下载安卓版</a>
</div>
</div>
<img class="area_right" src="{{asset('zealer_files/img_9c17cc22_phone.png')}}">
</div>
</div>
</li>
</ul>
<div class="header_search clear">
<input class="head_searchInput" placeholder="搜点什么...">
<div class="index_icons head_searchIcon global_gaNode" data-type="video" data-galable="home_header_search"></div>
</div>
</div>

</div>
</div>
<script id="showData.tpl" type="text/html">
<div class="msg_content">
<h2>欢迎你!</h2>
<a href="http://www.zealer.com/user?pagetype=setbasic" class="msg_btn_box">
<img src='' id="msg_pic"/>
</a>
<div id="msg_name"></div>
你与极客之间的距离，可能只差个性<br />的头像！快去完善吧~
<a href="http://www.zealer.com/user?pagetype=setbasic" class="msg_btn msg_btn_box">完善资料</a>
</div>
</script>



<div class="global_mHeader">
<div class="mHeader_menu"></div>
<div class="mHeader_right">
<a class="mHeader_login" href="http://www.zealer.com/login/?from=index&amp;redirect=http%3A%2F%2Fwww.zealer.com%2F">登录</a>
<a class="img_link clear" href="http://www.zealer.com/user?pagetype=setbasic">
<img class="user_img" src="{{asset('zealer_files/mb_pic30.gif')}}" alt="会员头像">
</a>
</div>
<ul class="mHeader_menuList">  @foreach($titles as $ti)
        @if($ti->tit_id<=3)
            <li><a class="global_gaNode" href="{{$ti->tit_url}}" >{{$ti->tit_name}}</a></li>
        @elseif($ti->tit_id<=6)

            <li><a class="global_gaNode" href="{{$ti->tit_url}}" target="_blank" >{{$ti->tit_name}}</a></li>

        @else

            <li><a href="{{$ti->tit_url}}" class="header_contactUs global_gaNode" target="_blank" rel="nofollow" >{{$ti->tit_name}}</a></li>

        @endif
    @endforeach
</ul>
</div>

<div class="global_appDownload">
<div class="appDownload_text">
<div class="appDownload_icon"></div>
<span class="text_title">ZEALER 手机客户端<span>
</span></span></div>
<a href="http://a.app.qq.com/o/simple.jsp?pkgname=com.zealer.app" class="appDownload_btn">立即下载</a>
</div>

<div class="wrap">
<div id="main" style="overflow: initial;">



<div class="slider_container">
<div class="slider_box">
<div id="slider1_container" style="position: relative; margin: 0px auto; top: 0px; left: 0px; width: 1920px; height: 500px; overflow: hidden;">









<div style="position: absolute; top: 0px; left: 0px; width: 1920px; height: 500px; transform-origin: 0px 0px 0px; transform: scale(1);"><div class="" style="position: relative; margin: 0px auto; top: 0px; left: 0px; width: 1920px; height: 500px; overflow: visible; display: block;"><div data-u="slides" style="position: absolute; left: 0px; top: 0px; width: 1920px; height: 500px; overflow: hidden; z-index: 0;"><div style="position: absolute; z-index: 0; pointer-events: none; left: -1920px; top: 0px;"></div></div><div data-u="slides" style="position: absolute; left: 0px; top: 0px; width: 1920px; height: 500px; overflow: hidden; z-index: 0;"><div style="width: 1920px; height: 500px; top: 0px; left: 0px; position: absolute; opacity: 0; background-color: rgb(0, 0, 0);"></div>


<div style="width: 1920px; height: 500px; top: 0px; left: -1920px; position: absolute; overflow: hidden; transform: perspective(2000px);">
<a href="http://plus.zealer.com/topic/cutfingers?id=3" class="global_gaNode" data-id="664" target="_blank" data-galable="home_banner_big_detail_1" style="transform: perspective(2000px);">
<img src="{{asset('zealer_files/a504cb239e24e94f3c23f735c2.jpg')}}" style="transform: perspective(2000px);">
</a>
<div style="width: 1920px; height: 500px; top: 0px; left: 0px; z-index: 1000; display: none;"></div></div>

<div style="width: 1920px; height: 500px; top: 0px; left: 0px; position: absolute; overflow: hidden; transform: perspective(2000px);">
<a href="http://www.zealer.com/post/472.html" class="global_gaNode" data-id="667" target="_blank" data-galable="home_banner_big_detail_2" style="transform: perspective(2000px);">
<img src="{{asset('zealer_files/f13a2025a46615205a29409cf3.jpg')}}" style="transform: perspective(2000px);">
</a>
<div style="width: 1920px; height: 500px; top: 0px; left: 0px; z-index: 1000; display: none;"></div></div>

<div style="width: 1920px; height: 500px; top: 0px; left: 1920px; position: absolute; overflow: hidden; transform: perspective(2000px);">
<a href="http://www.zealer.com/post/471.html" class="global_gaNode" data-id="666" target="_blank" data-galable="home_banner_big_detail_3" style="transform: perspective(2000px);">
<img src="{{asset('zealer_files/9b6839c12eeeb453766746409e.jpg')}}" style="transform: perspective(2000px);">
</a>
<div style="width: 1920px; height: 500px; top: 0px; left: 0px; z-index: 1000; display: none;"></div></div>

<div style="width: 1920px; height: 500px; top: 0px; left: -1920px; position: absolute; overflow: hidden; transform: perspective(2000px);">
<a href="http://plus.zealer.com/post/65926.html" class="global_gaNode" data-id="614" target="_blank" data-galable="home_banner_big_detail_4" style="transform: perspective(2000px);">
<img src="{{asset('zealer_files/b67f5481dbe01c4cf9cc2e9807.jpg')}}" style="transform: perspective(2000px);">
</a>
<div style="width: 1920px; height: 500px; top: 0px; left: 0px; z-index: 1000; display: none;"></div></div>
</div><div data-u="navigator" class="jssorb21" style="width: 150px; height: 2px; left: 885px;">


<div data-u="prototype" class="" style="position: absolute; left: 0px; top: 0px;"><span class="" style="font-size: 13px;">1</span></div><div data-u="prototype" class="av" style="position: absolute; left: 40px; top: 0px;"><span class="" style="font-size: 13px;">2</span></div><div data-u="prototype" class="" style="position: absolute; left: 80px; top: 0px;"><span class="" style="font-size: 13px;">3</span></div><div data-u="prototype" class="" style="position: absolute; left: 120px; top: 0px;"><span class="" style="font-size: 13px;">4</span></div></div><div class="arrow_box" style="width: 1425px; margin-left: -713px;">
<span data-u="arrowleft" class="jssora2l jssora2l global_gaNode" data-galable="home_banner_big_left" style="top: 220px;"></span>

<span data-u="arrowright" class="jssora2r jssora2r global_gaNode" data-galable="home_banner_big_right" style="top: 220px;"></span>
</div></div></div></div>

</div>
</div>


<ul class="banner_sec clear">
<li style="margin-right: 20px;">
<a class="global_gaNode" href="http://plus.zealer.com/post/66250.html" target="_blank" data-id="661" data-galable="home_banner_small_1">
<img src="{{asset('zealer_files/c7b24e7a02e3369921930375d4.jpg')}}">
</a>
</li>
<li style="margin-right: 20px;">
<a class="global_gaNode" href="http://plus.zealer.com/post/66226.html" target="_blank" data-id="656" data-galable="home_banner_small_2">
<img src="{{asset('zealer_files/545bc46d3fb3b7b62cc1213754.jpg')}}">
</a>
</li>
<li style="margin-right: 20px;">
<a class="global_gaNode" href="http://plus.zealer.com/post/66018.html" target="_blank" data-id="650" data-galable="home_banner_small_3">
<img src="{{asset('zealer_files/acbf711c6bc57c3d7be5e8c36d.jpg')}}">
</a>
</li>
<li>
<a class="global_gaNode" href="http://plus.zealer.com/post/66119.html" target="_blank" data-id="637" data-galable="home_banner_small_4">
<img src="{{asset('zealer_files/ef0c38a200d1428a667d49f2dc.jpg')}}">
</a>
</li>
</ul>




<div id="main_video">
<div class="video_wrap">
<div class="video_title clear">
<a class="global_gaNode" href="http://www.zealer.com/media" data-galable="home_media_nav_title">
<div class="video_titleIcon index_icons"></div>
<h1>官方视频</h1>
</a>
<ul class="video_titleList">
    @foreach($medias as $me)
<li><a class="global_gaNode" target="_blank" href="{{$me->media_url}}" cid="9" data-galable="home_media_nav_{{$me->media_id}}">{{$me->media_name}}</a></li>
@endforeach

</ul>
<div class="title_more index_icons"><a class="global_gaNode" href="http://www.zealer.com/media" data-galable="home_media_nav_more">更多</a></div>
</div>

<div class="video_container clear">
<div class="video_left">
<a class="global_gaNode" href="http://www.zealer.com/post/439.html" data-galable="home_media_video_1">
<img src="{{asset('zealer_files/5c94f8c9a47d8a30af9901f387.jpg')}}">
<span class="video_tip">手机简评</span>
<span class="video_icon index_icons"></span>
</a>
<a class="global_gaNode" href="http://www.zealer.com/post/439.html" data-galable="home_media_video_1"><h2>魅族 PRO 6</h2></a>
<p>选手机就看手机简评！</p>
</div>

<ul class="video_right">
<li class="video_list1">
<a href="http://www.zealer.com/post/472.html">
<img src="{{asset('zealer_files/ad37ed993a2ac2e27a2d533a39.jpg')}}">
<span class="video_tip">ZEALER 酷品</span>
<span class="video_icon index_icons"></span>
</a>
<a class="global_gaNode" href="http://www.zealer.com/post/472.html" data-label="home_media_video_2"><h2>全景相机 Insta 360</h2></a>
<p>简单好玩</p>
</li>
<li class="video_list2">
<a href="http://www.zealer.com/post/471.html">
<img src="{{asset('zealer_files/4b977e3390ebdbb9b71bf0ffff.jpg')}}">
<span class="video_tip">ZEALER TIPS</span>
<span class="video_icon index_icons"></span>
</a>
<a class="global_gaNode" href="http://www.zealer.com/post/471.html" data-label="home_media_video_3"><h2>再见 iOS 9，你好 iOS 10！</h2></a>
<p>每天一个 ZEALER TIPS！</p>
</li>
<li class="video_list3">
<a href="http://www.zealer.com/post/459.html">
<img src="{{asset('zealer_files/922cf59c19bc668f0631488e73.jpg')}}">
<span class="video_tip">ZEALER | UPPER</span>
<span class="video_icon index_icons"></span>
</a>
<a class="global_gaNode" href="http://www.zealer.com/post/459.html" data-label="home_media_video_4"><h2>格斗机器人 GANKER 诞生记</h2></a>
<p>机器人永不为奴！</p>
</li>
<li class="video_list4">
<a href="http://www.zealer.com/post/363.html">
<img src="{{asset('zealer_files/4c33e4902de747d0c8cc9ca646.jpg')}}">
<span class="video_tip">手机测评</span>
<span class="video_icon index_icons"></span>
</a>
<a class="global_gaNode" href="http://www.zealer.com/post/363.html" data-label="home_media_video_5"><h2>HTC 10 测评</h2></a>
<p>这可能是 ZEALER 最后一次 HTC 测评</p>
</li>
</ul>
</div>

<div class="video_series">
<!--
<div class="series_line"></div>
<div class="series_title">视频合辑</div>
-->
<div class="series_split_line"></div>
<ul class="series_list clear">
<li class="series_item0">
<a href="http://www.zealer.com/series/6" target="_blank">
<img src="{{asset('zealer_files/d6390dfdbd98fe183b6aaebc28.jpg')}}">
<span class="video_icon index_icons"></span>
</a>
<a class="global_gaNode" href="http://www.zealer.com/series/6" target="_blank" data-galable="home_media_series_1"><h3 class="series_subTitle">夏日桌面必备小单品</h3></a>
</li>
<li class="series_item1">
<a href="http://www.zealer.com/special/relativity" target="_blank">
<img src="{{asset('zealer_files/dc4d69d4dca24d727dd3805c47.jpg')}}">
<span class="video_icon index_icons"></span>
</a>
<a class="global_gaNode" href="http://www.zealer.com/special/relativity" target="_blank" data-galable="home_media_series_2"><h3 class="series_subTitle">科技相对论 第一季</h3></a>
</li>
<li class="series_item2">
<a href="http://www.zealer.com/series/1" target="_blank">
<img src="{{asset('zealer_files/b53e1783d4d5b72a69428672d5.jpg')}}">
<span class="video_icon index_icons"></span>
</a>
<a class="global_gaNode" href="http://www.zealer.com/series/1" target="_blank" data-galable="home_media_series_3"><h3 class="series_subTitle">如何打造王自如同款办公室</h3></a>
</li>
<li class="series_item3">
<a href="http://www.zealer.com/series/2" target="_blank">
<img src="{{asset('zealer_files/98bb2ee64db06ba2cc7d036a5d.jpg')}}">
<span class="video_icon index_icons"></span>
</a>
<a class="global_gaNode" href="http://www.zealer.com/series/2" target="_blank" data-galable="home_media_series_4"><h3 class="series_subTitle">三星 S7 edge 值得买吗？</h3></a>
</li>
</ul>
</div>
</div>

</div>


<div id="main_plus">
<div class="plus_wrap">
<div class="plus_title clear">
<a class="global_gaNode" href="http://plus.zealer.com/" data-galable="home_plus_nav_title">
<div class="plus_titleIcon index_icons"></div>
<h1>社区推荐</h1>
</a>
<span class="title_text">精选社区用户有趣的贴子</span>
<span class="title_more index_icons"><a class="global_gaNode" href="http://plus.zealer.com/" target="_blank" data-galable="home_plus_nav_more">更多</a></span>
</div>
<div class="plus_recommend">
<h2 class="recom_title plusArea_title">每日精选</h2>
<div class="recom_wrap clear">
<div class="recom_left">
<li class="recom_item0">
<a class="global_gaNode" href="http://plus.zealer.com/post/66196.html" target="_blank" data-galable="home_plus_recommend_1"><img src="{{asset('zealer_files/510f69cdd9ecdca31fbd71d53a.jpg')}}"></a>
<a class="global_gaNode" href="http://plus.zealer.com/post/66196.html" target="_blank" data-galable="home_plus_recommend_1">
<h3 class="recom_title">【DIY大神】自从知道了 DIY 电脑和水冷之后一去不复返了</h3>
</a>
<span class="recom_total">2015 人阅读</span>
</li>
<li class="recom_item1">
<a class="global_gaNode" href="http://plus.zealer.com/post/66246.html" target="_blank" data-galable="home_plus_recommend_2"><img src="{{asset('zealer_files/9fd73330a6a846cb3694aeaa6f.jpg')}}"></a>
<a class="global_gaNode" href="http://plus.zealer.com/post/66246.html" target="_blank" data-galable="home_plus_recommend_2">
<h3 class="recom_title">GTX 1060 性能实测：1999 元轻松掀翻 RX 480！</h3>
</a>
<span class="recom_total">4850 人阅读</span>
</li>
<li class="recom_item2">
<a class="global_gaNode" href="http://plus.zealer.com/post/66172.html" target="_blank" data-galable="home_plus_recommend_3"><img src="{{asset('zealer_files/c1e2f83ba3c42b4a5886e0b974.jpg')}}"></a>
<a class="global_gaNode" href="http://plus.zealer.com/post/66172.html" target="_blank" data-galable="home_plus_recommend_3">
<h3 class="recom_title">【夏日旅行】对我来说未曾到过的地方，皆是新奇的。</h3>
</a>
<span class="recom_total">1037 人阅读</span>
</li>
<li class="recom_item3">
<a class="global_gaNode" href="http://plus.zealer.com/post/65750.html" target="_blank" data-galable="home_plus_recommend_4"><img src="{{asset('zealer_files/0494864d79311a2181d42c61a1.jpg')}}"></a>
<a class="global_gaNode" href="http://plus.zealer.com/post/65750.html" target="_blank" data-galable="home_plus_recommend_4">
<h3 class="recom_title">【出行装备】高三理科 BOY 的小物件</h3>
</a>
<span class="recom_total">6567 人阅读</span>
</li>
<li class="recom_item4">
<a class="global_gaNode" href="http://plus.zealer.com/post/66181.html" target="_blank" data-galable="home_plus_recommend_5"><img src="{{asset('zealer_files/22e2eecb0fab91c591fcbd0cfb.jpg')}}"></a>
<a class="global_gaNode" href="http://plus.zealer.com/post/66181.html" target="_blank" data-galable="home_plus_recommend_5">
<h3 class="recom_title">梦想是否依旧坚持？魅族 MX6 正式发布！</h3>
</a>
<span class="recom_total">24290 人阅读</span>
</li>
<li class="recom_item5">
<a class="global_gaNode" href="http://plus.zealer.com/post/65954.html" target="_blank" data-galable="home_plus_recommend_6"><img src="{{asset('zealer_files/a3b9ab85903344d1c2727e258b.jpg')}}"></a>
<a class="global_gaNode" href="http://plus.zealer.com/post/65954.html" target="_blank" data-galable="home_plus_recommend_6">
<h3 class="recom_title">【晒桌面】成都 UI 设计师的自制桌面</h3>
</a>
<span class="recom_total">11993 人阅读</span>
</li>
</div>
<div class="recom_right">
<li style="margin-bottom: 20px;">
<a class="global_gaNode" href="http://plus.zealer.com/post/65972.html" target="_blank" data-galable="home_plus_recommend_banner_1"><img src="{{asset('zealer_files/fbdef1af137a0986b051b11569.jpg')}}"></a>
</li>
<li style="margin-bottom: 20px;">
<a class="global_gaNode" href="http://plus.zealer.com/post/65934.html" target="_blank" data-galable="home_plus_recommend_banner_2"><img src="{{asset('zealer_files/5cc61fea773712b4514e9902f5.jpg')}}"></a>
</li>
<li>
<a class="global_gaNode" href="http://plus.zealer.com/post/66110.html" target="_blank" data-galable="home_plus_recommend_banner_3"><img src="{{asset('zealer_files/e799ac2959a653405cac3418c8.jpg')}}"></a>
</li>
</div>
</div>
</div>
</div>


<div class="fix_bannerWrap">
<a class="globle_gaNode fix_bannerLink" href="http://plus.zealer.com/post/65519.html" target="_blank" data-id="585" data-galable="home_fix_banner">
<img src="{{asset('zealer_files/13b6d52a4f8e74bee1bf9c920b.jpg')}}">
</a>
</div>

<div class="plus_artWrap">
<div class="plus_article">
<h2 class="art_title plusArea_title">深度好文</h2>
<div class="art_wrap clear">
<div class="art_left">
<li class="article_item article_item0">
<h3 class="article_title">
<a class="global_gaNode" href="http://plus.zealer.com/report/65811.html" target="_blank" data-galable="home_plus_article_1">
<span class="title_type">  · </span>这电视，买了不吃亏</a>
</h3>
<a class="global_gaNode" href="http://plus.zealer.com/report/65811.html" target="_blank" data-galable="home_plus_article_1"><img src="{{asset('zealer_files/84ca7de97aa9e4c5649981b170.jpg')}}"></a>
<p class="article_content">身为半个南京人，提到电视，就不得不吼一声"熊猫PANDA"！作为曾经业界一霸的熊猫电视，在如今的市场似乎快找不到...</p>
<span class="article_total">2051 人阅读</span>

</li>
<li class="article_item article_item1">
<h3 class="article_title">
<a class="global_gaNode" href="http://plus.zealer.com/report/65766.html" target="_blank" data-galable="home_plus_article_2">
<span class="title_type">  · </span>PRO 6,这个旗舰不全面</a>
</h3>
<a class="global_gaNode" href="http://plus.zealer.com/report/65766.html" target="_blank" data-galable="home_plus_article_2"><img src="{{asset('zealer_files/1c2c6c7394dff50fee1d94b872.jpg')}}"></a>
<p class="article_content">啊哈，终于来到了“魅族·联发科四月狂欢三连弹”的最后一台机，魅族和联发科基情满满，也随着联发科获得CDMA牌...</p>
<span class="article_total">4995 人阅读</span>

</li>
<li class="article_item article_item2">
<h3 class="article_title">
<a class="global_gaNode" href="http://plus.zealer.com/report/65976.html" target="_blank" data-galable="home_plus_article_3">
<span class="title_type">  · </span>一加 3，谁敢说你丑！</a>
</h3>
<a class="global_gaNode" href="http://plus.zealer.com/report/65976.html" target="_blank" data-galable="home_plus_article_3"><img src="{{asset('zealer_files/84e3e0a3f287bb837f0c5864df.jpg')}}"></a>
<p class="article_content">首先！感谢 ZEALER 提供的众测机会！感恩的心，感谢有你！开始测评之前，让我们先来欣赏一下，这次一加3手机的主...</p>
<span class="article_total">13475 人阅读</span>

</li>
<li class="article_item article_item3">
<h3 class="article_title">
<a class="global_gaNode" href="http://plus.zealer.com/report/66082.html" target="_blank" data-galable="home_plus_article_4">
<span class="title_type">  · </span>魅族 PRO6 大战 一加 3</a>
</h3>
<a class="global_gaNode" href="http://plus.zealer.com/report/66082.html" target="_blank" data-galable="home_plus_article_4"><img src="{{asset('zealer_files/7e41b6d1e59c93e88a274a5641.jpg')}}"></a>
<p class="article_content">距离魅族Pro6的发布已经过去了整整3个月。3个月的时间说短不短，说长不长。在这三个月之间，魅族自己就已经把魅...</p>
<span class="article_total">22981 人阅读</span>

</li>
<li class="article_item article_item4">
<h3 class="article_title">
<a class="global_gaNode" href="http://plus.zealer.com/post/59697.html" target="_blank" data-galable="home_plus_article_5">
<span class="title_type">  · </span>厂商增长乏力的根本原因</a>
</h3>
<a class="global_gaNode" href="http://plus.zealer.com/post/59697.html" target="_blank" data-galable="home_plus_article_5"><img src="{{asset('zealer_files/c218a5c1e74d1a68d922a2b957.jpg')}}"></a>
<p class="article_content">在竞争激烈的手机行业，即使厂商们看上去已经非常努力，但是去年非核心厂商都过得很不好，有些厂商为了放大规模...</p>
<span class="article_total">5479 人阅读</span>

</li>
<li class="article_item article_item5">
<h3 class="article_title">
<a class="global_gaNode" href="http://plus.zealer.com/report/65594.html" target="_blank" data-galable="home_plus_article_6">
<span class="title_type">  · </span>不知道 NAS 是啥？说不定你就需要</a>
</h3>
<a class="global_gaNode" href="http://plus.zealer.com/report/65594.html" target="_blank" data-galable="home_plus_article_6"><img src="{{asset('zealer_files/ad2232efeb45f6a1d0acd2cfc2.jpg')}}"></a>
<p class="article_content">写在前面：作为年龄最大的90后一代，对于"从来没用过NAS设备"这件事来说，我不打算有所隐瞒，并且我也不惭愧，任...</p>
<span class="article_total">11911 人阅读</span>

</li>
</div>
<div class="art_right">
<li style="margin-bottom: 20px;">
<a class="global_gaNode" href="http://plus.zealer.com/post/65868.html" target="_blank" data-galable="home_plus_article_banner_1"><img src="{{asset('zealer_files/174bf0ecbbbc7356eb69404ee2.jpg')}}"></a>
</li>
<li style="margin-bottom: 20px;">
<a class="global_gaNode" href="http://plus.zealer.com/post/65842.html" target="_blank" data-galable="home_plus_article_banner_2"><img src="{{asset('zealer_files/8e6f188e3f52fd74d56c6097c7.jpg')}}"></a>
</li>
<li>
<a class="global_gaNode" href="http://plus.zealer.com/test/65836.html" target="_blank" data-galable="home_plus_article_banner_3"><img src="{{asset('zealer_files/f8cff193677326ce794e0147b2.jpg')}}"></a>
</li>
</div>
</div>
</div>
</div>

</div>


<div id="main_phone">
<div class="phone_wrap clear">
<div class="phone_header plus_title">
<a href="http://tool.zealer.com/" class="header_title">手机工具</a>
<div class="header_tag">
<a href="http://tool.zealer.com/list">手机</a>
<a href="http://tool.zealer.com/component">专题</a>
</div>
<a href="http://tool.zealer.com/" class="header_more index_icons">更多</a>
</div>

<ul class="phone_component list_pic_3 clear">
<li class="each_0">
<a href="http://tool.zealer.com/interest/123" target="_blank">
<img src="{{asset('zealer_files/ae0ea574d3b7160901b50aee7c.jpg')}}" data-retina="http://img0.zealer.com/cd/ab/d0/f9a00b34975b81796f39187afd.jpg')}}">
<span class="each_shadow shadow_0"></span>
</a>
</li>
<li class="each_1">
<a href="http://tool.zealer.com/interest/118" target="_blank">
<img src="{{asset('zealer_files/8118571061788d3a3a5560c773.jpg')}}" data-retina="http://img0.zealer.com/71/e8/cd/57a0f4f1e5967f245178826d36.jpg')}}">
<span class="each_shadow shadow_1"></span>
</a>
</li>
<li class="each_2">
<a href="http://tool.zealer.com/interest/124" target="_blank">
<img src="{{asset('zealer_files/8a7e47acf96ce7b170a8424fa3.jpg')}}" data-retina="http://img0.zealer.com/38/49/d7/829a0ac3019792968f684134c1.jpg')}}">
<span class="each_shadow shadow_2"></span>
</a>
</li>
<li class="each_3">
<a href="http://tool.zealer.com/interest/119" target="_blank">
<img src="{{asset('zealer_files/55d7662e7376cf30f4efc375a6.jpg')}}" data-retina="http://img0.zealer.com/21/ae/25/23fcb0dd69b6c1546ca1ac4522.jpg')}}">
<span class="each_shadow shadow_3"></span>
</a>
</li>
</ul>

<ul class="phone_phone clear">
<li>
<a href="http://tool.zealer.com/post/1" class="clear">
<span class="phone_img">
<img src="{{asset('zealer_files/00e58bc6dc609df4f3c71a4a9a.jpg')}}">
</span>
<span class="phone_name">Apple iPhone 6s</span>
</a>
</li>
<li>
<a href="http://tool.zealer.com/post/2" class="clear">
<span class="phone_img">
<img src="{{asset('zealer_files/b18ccfcc411de07adda7c1d7bd.jpg')}}">
</span>
<span class="phone_name">Apple iPhone 6s Plus</span>
</a>
</li>
<li>
<a href="http://tool.zealer.com/post/252" class="clear">
<span class="phone_img">
<img src="{{asset('zealer_files/cdb51679a4774ded093ed44c1d.jpg')}}">
</span>
<span class="phone_name">HTC HTC Desire 830</span>
</a>
</li>
<li>
<a href="http://tool.zealer.com/post/259" class="clear">
<span class="phone_img">
<img src="{{asset('zealer_files/333fb2aa0966cda436ea24aa5f.jpg')}}">
</span>
<span class="phone_name">小米 小米 Max</span>
</a>
</li>
</ul>
</div>

</div>


<div id="main_lab">

<div class="lab_wrap">
<div class="wrap_title clear">
<a class="title_name global_gaNode" href="http://lab.zealer.com/" target="_blank" data-galable="home_lab_nav_title"><h2>实验室</h2></a>
<span class="title_tab">
<a class="global_gaNode" href="http://lab.zealer.com/content?page=1" target="_blank" data-galable="home_lab_nav_1">内容</a>
<a class="global_gaNode" href="http://lab.zealer.com/abstract" target="_blank" data-galable="home_lab_nav_2">简介</a>
<a class="global_gaNode" href="http://lab.zealer.com/consult" target="_blank" data-galable="home_lab_nav_3">咨询</a>
<a class="global_gaNode" href="http://lab.zealer.com/testing" target="_blank" data-galable="home_lab_nav_4">众测</a>
<a class="global_gaNode" href="http://lab.zealer.com/" target="_blank" data-galable="home_lab_nav_more">更多</a>
</span>
</div>
<ul class="lab_list clear">

<li style="margin-right: 2%;">
<a class="global_gaNode" href="http://lab.zealer.com/abstract" target="_blank" data-galable="home_lab_detail_1">
<img src="{{asset('zealer_files/19d1e8a8712c5b31665112d216.jpg')}}" alt="「做消费者自己的实验室」">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">更多</span>
</a>
<h3 class="list_title">
「做消费者自己的实验室」</h3>
</li>

<li>
<a class="global_gaNode" href="http://lab.zealer.com/consult" target="_blank" data-galable="home_lab_detail_2">
<img src="{{asset('zealer_files/1cc17ff69818fb691a86728761.jpg')}}" alt="「检测&amp;咨询」正式上线">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">更多</span>
</a>
<h3 class="list_title">
「检测&amp;咨询」正式上线</h3>
</li>

<li style="margin-right: 2%;">
<a class="global_gaNode" href="http://lab.zealer.com/content?page=1" target="_blank" data-galable="home_lab_detail_3">
<img src="{{asset('zealer_files/01da5367483f709312256b8a70.jpg')}}" alt="测评分析 尽在其中">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">更多</span>
</a>
<h3 class="list_title">
测评分析 尽在其中</h3>
</li>

<li>
<a class="global_gaNode" href="http://lab.zealer.com/testing" target="_blank" data-galable="home_lab_detail_4">
<img src="{{asset('zealer_files/7cbf51d7ceb75158aaaf7797f0.jpg')}}" alt="众测空间 期待有你">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">更多</span>
</a>
<h3 class="list_title">
众测空间 期待有你</h3>
</li>
</ul>
</div>

<div class="lab_mWrap">
<a href="http://lab.zealer.com/" class="lab_mIndex">
<img src="{{asset('zealer_files/index_lab.png')}}">
</a>

<ul class="lab_mMenu clear">
<li><a href="http://lab.zealer.com/content?page=1">内容</a></li>
<li><a href="http://lab.zealer.com/abstract">简介</a></li>
<li><a href="http://lab.zealer.com/consult">咨询</a></li>
<li><a class="labMenu_last" href="http://lab.zealer.com/testing">众测</a></li>
</ul>
</div>

</div>


<div id="main_rephone">

<div class="rephone_wrap clear">

<div class="rephone_list clear">
<div class="wrap_title clear">
<a class="title_name global_gaNode" href="http://fix.zealer.com/rephone/index" target="_blank" data-galable="home_rephone_nav_title"><h2>易手・良品</h2></a>
<span class="title_tab">
<a class="global_gaNode" href="http://fix.zealer.com/rephone/index" target="_blank" data-galable="home_rephone_nav_1">手机</a>
<a class="global_gaNode" href="http://fix.zealer.com/rephone/index" target="_blank" data-galable="home_rephone_nav_2">配件</a>
</span>
</div>
<ul class="list_img clear">

<li class="rephone_0">
<a class="global_gaNode" href="http://fix.zealer.com/rephone/index" target="_blank" data-galable="home_rephone_detail_1">
<img src="{{asset('zealer_files/ed2833cd5919bb5699625d332d.jpg')}}" alt="iPhone 6s Plus">
</a>
</li>

<li class="rephone_1">
<a class="global_gaNode" href="http://fix.zealer.com/rephone/index" target="_blank" data-galable="home_rephone_detail_2">
<img src="{{asset('zealer_files/128c47931e3055723b4cacf41a.jpg')}}" alt="iPhone 6s">
</a>
</li>

<li class="rephone_2">
<a class="global_gaNode" href="http://fix.zealer.com/rephone/index" target="_blank" data-galable="home_rephone_detail_3">
<img src="{{asset('zealer_files/0696aeef24f9402038f487d32d.jpg')}}" alt="iPhone 6 Plus">
</a>
</li>

<li class="rephone_3">
<a class="global_gaNode" href="http://fix.zealer.com/rephone/index" target="_blank" data-galable="home_rephone_detail_4">
<img src="{{asset('zealer_files/e0d4445d972a0c8cb878bf3c95.jpg')}}" alt="iPhone 6">
</a>
</li>
</ul>
</div>


<div class="fix_list clear">
<div class="wrap_title clear">
<a class="title_name fix_title global_gaNode" href="http://fix.zealer.com/" target="_blank" data-galable="home_fix_nav_title"><h2>维修</h2></a>
</div>
<img alt="ZEALER FIX" class="fix_logo" src="{{asset('zealer_files/fix_logo.png')}}">

<ul class="fix_menu clear">
<li class="menu_item">
<a href="http://fix.zealer.com/mobile"><div class="menu_name fix_water fix_icons">手机进水</div></a>
</li>
<li class="menu_item">
<a href="http://fix.zealer.com/mobile"><div class="menu_name fix_power fix_icons">无法开机</div></a>
</li>
<li class="menu_item">
<a href="http://fix.zealer.com/mobile"><div class="menu_name fix_damage fix_icons">严重摔坏</div></a>
</li>
<li class="menu_item">
<a href="http://fix.zealer.com/mobile"><div class="menu_name fix_root fix_icons">刷机错误</div></a>
</li>
<li class="menu_item">
<a href="http://fix.zealer.com/mobile"><div class="menu_name fix_sim fix_icons">无 SIM 卡</div></a>
</li>
</ul>

<div class="wrap_option clear">
<div class="chose_device chose_txt">请选择机型</div>
<dl class="option_list">
<dt class="list_name list_title" style="background: none">iPhone</dt>
</dl>
<div class="chose_problem chose_txt">请选择故障现象</div>
<dl class="option_list">
<dt class="list_problem list_title">故障</dt>
<dd class="list_iphone list_des">
<div class="des_select" addr="http://fix.zealer.com/service/53">进水</div>
<div class="des_select" addr="http://fix.zealer.com/service/57">无法开机</div>
<div class="des_select" addr="http://fix.zealer.com/service/58">严重摔坏</div>
<div class="des_select" addr="http://fix.zealer.com/service/39">无Wi-Fi</div>
<div class="des_select" addr="http://fix.zealer.com/service/60">刷机错误</div>
<div class="des_select" addr="http://fix.zealer.com/service/107">无SIM卡</div>
<div class="des_select" addr="http://fix.zealer.com/service/59">其他</div>
</dd>
</dl>
<div class="wrap_go">
<span></span>
<a class="global_gaNode" href="http://fix.zealer.com/repair/index" target="_blank" rel="nofollow" data-galable="home_fix_detail_btn">进入维修</a>
</div>
</div>
</div>

</div>
</div>
</div>
</div>


<div class="global_footer">
<div class="footer_inner">
<div class="inner_link clear">
<dl>

<p class="logo_footer index_icons"></p>
</dl>
<dl>
<dt>业务</dt>
<dd>
<a class="global_gaNode" data-galable="home_footer_nav_link" href="http://fix.zealer.com/" rel="nofollow">手机服务</a>
<a class="global_gaNode" data-galable="home_footer_nav_link" href="http://lab.zealer.com/" rel="nofollow">实验室</a>
<a class="global_gaNode" data-galable="home_footer_nav_link" href="http://plus.zealer.com/" rel="nofollow">社区</a>
</dd>
</dl>
<dl>
<dt>关于我们</dt>
<dd>
<a class="global_gaNode" data-galable="home_footer_nav_link" href="http://www.zealer.com/about.html?type=item" rel="nofollow">会员条款</a>
<a class="global_gaNode" data-galable="home_footer_nav_link" href="http://www.zealer.com/about.html?type=join" rel="nofollow">加入我们</a>
<a class="global_gaNode" data-galable="home_footer_nav_link" href="http://www.zealer.com/about.html?type=about" rel="nofollow">关于 ZEALER</a>
</dd>
</dl>
<dl class="footer_follow">
<dt>关注我们</dt>
<dd>
<a class="global_gaNode" data-galable="home_footer_nav_link" href="http://weibo.com/zealerchina" target="_blank" rel="nofollow">新浪微博</a>
<a class="global_gaNode" data-galable="home_footer_nav_link" href="http://www.zealer.com/about?type=contect" rel="nofollow">联系我们</a>
</dd>
</dl>
<dl class="footer_wechat">
<dt>官方微信</dt>
<dd class="wechat_img"></dd>
</dl>
<dl class="footer_appDownload">
<dt>APP 下载</dt>
<dd class="app_img"></dd>
</dl>
</div>



<div class="inner_tag clear">
<div><ul><span>友情链接</span></ul></div>
<div class="inner_tag_seolink">
<ul>
<li>
<a class="global_gaNode" href="http://www.mydrivers.com/" target="_blank" data-galable="home_footer_friend_link">
快科技</a>
</li>
<li>
<a class="global_gaNode" href="http://www.91.com/" target="_blank" data-galable="home_footer_friend_link">
91门户</a>
</li>
<li>
<a class="global_gaNode" href="http://www.gfan.com/" target="_blank" data-galable="home_footer_friend_link">
机锋网</a>
</li>
<li>
<a class="global_gaNode" href="http://www.romzhijia.net/" target="_blank" data-galable="home_footer_friend_link">
ROM之家</a>
</li>
<li>
<a class="global_gaNode" href="http://digi.163.com/" target="_blank" data-galable="home_footer_friend_link">
网易数码</a>
</li>
<li>
<a class="global_gaNode" href="http://www.ithome.com/" target="_blank" data-galable="home_footer_friend_link">
IT之家</a>
</li>
<li>
<a class="global_gaNode" href="http://www.qianzhan.com/" target="_blank" data-galable="home_footer_friend_link">
前瞻网</a>
</li>
<li>
<a class="global_gaNode" href="http://www.feng.com/" target="_blank" data-galable="home_footer_friend_link">
威锋网</a>
</li>
<li>
<a class="global_gaNode" href="http://www.fengniao.com/" target="_blank" data-galable="home_footer_friend_link">
蜂鸟网</a>
</li>
<li>
<a class="global_gaNode" href="http://www.iheima.com/" target="_blank" data-galable="home_footer_friend_link">
i黑马</a>
</li>
<li>
<a class="global_gaNode" href="http://www.tuicool.com/" target="_blank" data-galable="home_footer_friend_link">
推酷网</a>
</li>
<li>
<a class="global_gaNode" href="http://www.yixieshi.com/" target="_blank" data-galable="home_footer_friend_link">
互联网一些事</a>
</li>
<li>
<a class="global_gaNode" href="http://www.imobile.com.cn/" target="_blank" data-galable="home_footer_friend_link">
手机之家</a>
</li>
<li>
<a class="global_gaNode" href="http://www.it168.com/" target="_blank" data-galable="home_footer_friend_link">
IT168</a>
</li>
<li>
<a class="global_gaNode" href="http://www.app111.com/" target="_blank" data-galable="home_footer_friend_link">
苹果园</a>
</li>
<li>
<a class="global_gaNode" href="http://www.evolife.cn/" target="_blank" data-galable="home_footer_friend_link">
爱活网</a>
</li>
<li>
<a class="global_gaNode" href="http://www.eoemarket.com/" target="_blank" data-galable="home_footer_friend_link">
优亿市场</a>
</li>
<li>
<a class="global_gaNode" href="http://www.leiphone.com/" target="_blank" data-galable="home_footer_friend_link">
雷锋网</a>
</li>
<li>
<a class="global_gaNode" href="http://ask.zealer.com/" target="_blank" data-galable="home_footer_friend_link">
科技问答</a>
</li>
<li>
<a class="global_gaNode" href="http://www.techmiao.com/" target="_blank" data-galable="home_footer_friend_link">
机智猫</a>
</li>
</ul>
</div>
</div>


<div class="footer_message">
<div class="footer_pcMsg clear">
<div class="inner_copyr">
<img class="inner_lisense" src="{{asset('zealer_files/img_e90c7a45_global_footer_lisence.png')}}">
<span class="inner_no"><a class="global_gaNode" data-galable="home_footer_nav_link" href="http://www.miitbeian.gov.cn/" target="_blank" rel="nofollow">粤ICP备12076188号-1</a>&nbsp;</span>
<span class="inner_img">
<a class="global_gaNode" data-galable="home_footer_nav_link" href="http://szcert.ebs.org.cn/1d7f198a-09f0-4844-8212-07761b11dffe" target="_blank" rel="nofollow">
<img src="{{asset('zealer_files/newGovIcon.gif')}}" title="深圳市市场监督管理局企业主体身份公示" alt="深圳市市场监督管理局企业主体身份公示" width="80" height="33" border="0" style="border-width:0px;border:hidden; border:none;">
 </a>
</span>
</div>
</div>

<div class="footer_mMsg">
<div class="mMsg_slogen"></div>
<div>© 2016 ZEALER | 粤ICP备12076188号-1 </div>
</div>
</div>
</div>
</div>

<div class="side_btn">
<span class="contect_btn"></span>
<span class="to_up"></span>
</div>

<div class="bg_writer">
<div class="content_writer">
<p>我们十分重视您的体验感受</p>
<p>请写下您的建议或者吐槽帮助我们更好的改进</p>
</div>
</div>




<script src="{{asset('zealer_files/jquery-1.10.2.min.js')}}"></script>

<script src="{{asset('zealer_files/jssor.slider.min.js')}}"></script><script src="{{asset('resources/views/zealer/zealer_files/libs_46276.js')}}"></script>
<script src="{{asset('zealer_files/global_4eae39f142.js')}}"></script>
<script src="{{asset('zealer_files/stat.js')}}"></script>
<script src="{{asset('zealer_files/page_d849f39bbf.js')}}"></script>

<script>
$(function(){

 Z.use('newWww/banner');Z.use('videoList/videoList');Z.use('plusList/plusList');Z.use('index/phoneList', {phone_host: 'http://tool.zealer.com/'});Z.use('labList/labList');Z.use('index/page');Z.use('global/header');Z.use('footer/footer');
});
</script>


<script type="text/javascript">
var _hmt = _hmt || [];
    (function() {
      var hm = document.createElement("script");
      hm.src = "//hm.baidu.com/hm.js?93a776aa5a5632380561feba017dd90f";
      var s = document.getElementsByTagName("script")[0];
      s.parentNode.insertBefore(hm, s);
    })();
</script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-42162857-1', 'zealer.com');
  ga('send', 'pageview');
</script>
<script>
// 百度推送， 上线请打开
(function(){var bp = document.createElement('script');bp.src= '//push.zhanzhang.baidu.com/push.js';var s = document.getElementsByTagName("script")[0];s.parentNode.insertBefore(bp, s);})();
</script>


<div class="global_dialog"><div class="dialog_closebg"></div><div class="dialog_inner autoHeight contect_dialog" style="margin-left: -230px; margin-top: -110px; width: 460px; height: 220px;"><div class="dialog_content"><div class="user_reply" style="display: block;">
<div class="bg_title">
<span style="width:13px; height:14px; background-position:0 -106px;" class="title_logo"></span>
</div>
<div class="bg_content">
<div class="contect_box">
<textarea class="content_contect">请输入您的反馈内容...</textarea>
<div>
<button class="contect_btn">提交</button>
</div>
</div>
</div>
</div></div></div></div><div style="position: static; width: 0px; height: 0px; border: none; padding: 0px; margin: 0px;"><div id="trans-tooltip"><div id="tip-left-top" style="background: url(&quot;chrome-extension://ikkbfngojljohpekonpldkamedehakni/imgs/map/tip-left-top.png&quot;);"></div><div id="tip-top" style="background: url(&quot;chrome-extension://ikkbfngojljohpekonpldkamedehakni/imgs/map/tip-top.png&quot;) repeat-x;"></div><div id="tip-right-top" style="background: url(&quot;chrome-extension://ikkbfngojljohpekonpldkamedehakni/imgs/map/tip-right-top.png&quot;);"></div><div id="tip-right" style="background: url(&quot;chrome-extension://ikkbfngojljohpekonpldkamedehakni/imgs/map/tip-right.png&quot;) repeat-y;"></div><div id="tip-right-bottom" style="background: url(&quot;chrome-extension://ikkbfngojljohpekonpldkamedehakni/imgs/map/tip-right-bottom.png&quot;);"></div><div id="tip-bottom" style="background: url(&quot;chrome-extension://ikkbfngojljohpekonpldkamedehakni/imgs/map/tip-bottom.png&quot;) repeat-x;"></div><div id="tip-left-bottom" style="background: url(&quot;chrome-extension://ikkbfngojljohpekonpldkamedehakni/imgs/map/tip-left-bottom.png&quot;);"></div><div id="tip-left" style="background: url(&quot;chrome-extension://ikkbfngojljohpekonpldkamedehakni/imgs/map/tip-left.png&quot;);"></div><div id="trans-content"></div></div><div id="tip-arrow-bottom" style="background: url(&quot;chrome-extension://ikkbfngojljohpekonpldkamedehakni/imgs/map/tip-arrow-bottom.png&quot;);"></div><div id="tip-arrow-top" style="background: url(&quot;chrome-extension://ikkbfngojljohpekonpldkamedehakni/imgs/map/tip-arrow-top.png&quot;);"></div></div></body></html>