@extends('zealer.same')
@section('content')
 <div class="media_content">
<h2 class="hand_title">全部</h2>
<p class="hand_recommend">全部</p>
<p class="=&quot;hand_tag&quot;">热门标签</p>
<span class="hand_btn">
<a class="btn_active" href="javascript:;" cid="6" tid="0">最新</a>
</span>
<ul class="hand_video">
 
<li totalnum="402">
<a href="http://www.zealer.com/post/472.html">
<img src="{{asset('zealer_files/e714762fe75a14b5c4f45a2225.jpg')}}" alt="「ZEALER | 酷品」简单好玩的全景相机 Insta 360">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
简单好玩的全景相机 Insta 360</p>
</li>
 
<li totalnum="402">
<a href="http://www.zealer.com/post/471.html">
<img src="{{asset('zealer_files/0ec5e2fa94229736749f0aa8be.jpg')}}" alt="再见 iOS 9，你好 iOS 10！">
<span class="list_cover" style="opacity: 0;"></span>
<span class="left_line" style="opacity: 0; left: 90px;"></span>
<span class="right_line" style="opacity: 0; right: 90px;"></span>
<span class="list_play" style="opacity: 0; top: 20px;">播放</span>
</a>
<p>
再见 iOS 9，你好 iOS 10！</p>
</li>
 
<li totalnum="402">
<a href="http://www.zealer.com/post/470.html">
<img src="{{asset('zealer_files/1da6dc5e63825900cec1cdf311.jpg')}}" alt="「ZEALER | 酷品」银河战甲 无穷我的乐趣！">
<span class="list_cover" style="opacity: 0;"></span>
<span class="left_line" style="opacity: 0; left: 90px;"></span>
<span class="right_line" style="opacity: 0; right: 90px;"></span>
<span class="list_play" style="opacity: 0; top: 20px;">播放</span>
</a>
<p>
银河战甲 无穷我的乐趣！</p>
</li>
 
<li totalnum="402">
<a href="http://www.zealer.com/post/469.html">
<img src="{{asset('zealer_files/d86725bfeaca81376c7116f48e.jpg')}}" alt="有种噪音能让你睡得更香">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
有种噪音能让你睡得更香</p>
</li>
 
<li totalnum="402">
<a href="http://www.zealer.com/post/468.html">
<img src="{{asset('zealer_files/80878c85501b1e8fe3df44b98b.jpg')}}" alt="「ZEALER | Tips」蓝牙5.0 这次不只是更快更远">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
蓝牙5.0 这次不只是更快更远</p>
</li>
 
<li totalnum="402">
<a href="http://www.zealer.com/post/467.html">
<img src="{{asset('zealer_files/60d5dd546aa92cfb5fa7848b39.jpg')}}" alt="「ZEALER | 酷品」价格实惠，功能全面的 bong3 HR 手环">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
价格实惠，功能全面的 bong3 HR 手环</p>
</li>
 
<li totalnum="402">
<a href="http://www.zealer.com/post/466.html">
<img src="{{asset('zealer_files/ae6d30f64bb7d7a5b319f969cb.jpg')}}" alt="「ZEALER | Tips」全网不是你想通 想通就能通">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
全网不是你想通 想通就能通</p>
</li>
 
<li totalnum="402">
<a href="http://www.zealer.com/post/465.html">
<img src="{{asset('zealer_files/519771939d6e94308b2ed174b3.jpg')}}" alt="「ZEALER | 酷品」触摸未来 HTC Vive ">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
触摸未来 HTC Vive </p>
</li>
 
<li totalnum="402">
<a href="http://www.zealer.com/post/464.html">
<img src="{{asset('zealer_files/d72405bff504cec32d394dc961.jpg')}}" alt="「慧问」你会爱上机器人吗？">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
你会爱上机器人吗？</p>
</li>
 
<li totalnum="402">
<a href="http://www.zealer.com/post/463.html">
<img src="{{asset('zealer_files/79bbc348c7d14cf7833f5c6f1e.jpg')}}" alt="「ZEALER | Tips」想在中国玩 Pokemon Go  你应该知道的几件事">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
想在中国玩 Pokemon Go  你应该知道的...</p>
</li>
 
<li totalnum="402">
<a href="http://www.zealer.com/post/462.html">
<img src="{{asset('zealer_files/9836a9a1ed2864578ac3eeba2b.jpg')}}" alt="「ZEALER | 酷品」你的移动影院--嗨镜">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
你的移动影院--嗨镜</p>
</li>
 
<li totalnum="402">
<a href="http://www.zealer.com/post/461.html">
<img src="{{asset('zealer_files/826563f70e9c39d241268ca2e2.jpg')}}" alt="「ZEALER | Tips」玩游戏网速卡？四招给你的网速做手术！">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
玩游戏网速卡？四招给你的网速做手术...</p>
</li>
 
<li totalnum="402">
<a href="http://www.zealer.com/post/460.html">
<img src="{{asset('zealer_files/b0bc4f0fb96e764f71c919a4fd.jpg')}}" alt="「ZEALER | Tips」VR很爽，可是WE ARE很晕，怎么破？！">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
VR很爽，可是WE ARE很晕，怎么破？！</p>
</li>
 
<li totalnum="402">
<a href="http://www.zealer.com/post/459.html">
<img src="{{asset('zealer_files/3d5e5d6ca87da3e5b742917129.jpg')}}" alt="「ZEALER｜UPPER」机器人永不为奴！格斗机器人GANKER诞生记">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
机器人永不为奴！格斗机器人GANKER诞...</p>
</li>
 
<li totalnum="402">
<a href="http://www.zealer.com/post/458.html">
<img src="{{asset('zealer_files/4087bca50687731ae5c765b5e1.jpg')}}" alt="「ZEALER | 酷品」GOFree 蓝牙音箱「粗暴」体验">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
GOFree 蓝牙音箱体验</p>
</li>
 
<li totalnum="402">
<a href="http://www.zealer.com/post/456.html">
<img src="{{asset('zealer_files/ec74b55c834086dbdf44e88a28.jpg')}}" alt="「ZEALER | Tips」手机进水不可怕，就怕机主没文化！">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
手机进水不可怕，就怕机主没文化！</p>
</li>
 
<li totalnum="402">
<a href="http://www.zealer.com/post/455.html">
<img src="{{asset('zealer_files/81a36328d15d86ebb5f5932fad.jpg')}}" alt="「ZEALER | 酷品」出门好助手，小米电助力单车">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
出门好助手，小米电助力单车</p>
</li>
 
<li totalnum="402">
<a href="http://www.zealer.com/post/454.html">
<img src="{{asset('zealer_files/d6df5f76f2bfb4162420c31235.jpg')}}" alt="「ZEALER | 酷品」微软爸爸的黑科技 HoloLens 未来体验">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
微软爸爸的黑科技 HoloLens 未来体验</p>
</li>
 
<li totalnum="402">
<a href="http://www.zealer.com/post/453.html">
<img src="{{asset('zealer_files/01e697a9eafdfd0d81f755e803.jpg')}}" alt="「ZEALER | Tips」那些年 学渣们错过的神器">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
那些年 学渣们错过的神器</p>
</li>
 
<li totalnum="402">
<a href="http://www.zealer.com/post/452.html">
<img src="{{asset('zealer_files/db3a17c6b9da72ba98414fef2c.jpg')}}" alt="「ZEALER | Tips」不实名认证 连红包都抢不了？">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
不实名认证 连红包都抢不了？</p>
</li>
 
<li totalnum="402">
<a href="http://www.zealer.com/post/451.html">
<img src="{{asset('zealer_files/5ac1a8cee7af1a680a4435d9fd.jpg')}}" alt="「慧问」千万别在街上玩VR，否则后果自负">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
千万别在街上玩VR，否则后果自负</p>
</li>

</ul>

  @endsection