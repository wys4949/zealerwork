@extends('zealer.same')
@section('content')

<div class="media_content">
<h2 class="hand_title">科技相对论</h2>
<p class="hand_recommend"></p>
<p class="=&quot;hand_tag&quot;">热门标签</p>
<span class="hand_btn">
<a class="btn_active" href="javascript:;" cid="2" tid="0">最新</a>
</span>
<ul class="hand_video">
 
<li totalnum="18">
<a href="http://www.zealer.com/post/348.html">
<img src="{{asset('zealer_files/393b035a9097d8b595253e624e.jpg')}}" alt="手机还是武器  万万没想到身边的科技产品的阴暗面">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
手机还是武器  万万没想到身边的科技...</p>
</li>
 
<li totalnum="18">
<a href="http://www.zealer.com/post/242.html">
<img src="{{asset('zealer_files/5e635fe265fa1f1affcfea910f.jpg')}}" alt="「科技相对论」最全面的极客养成指南">
<span class="list_cover" style="opacity: 0;"></span>
<span class="left_line" style="opacity: 0; left: 90px;"></span>
<span class="right_line" style="opacity: 0; right: 90px;"></span>
<span class="list_play" style="opacity: 0; top: 20px;">播放</span>
</a>
<p>
「科技相对论」最全面的极客养成指南</p>
</li>
 
<li totalnum="18">
<a href="http://www.zealer.com/post/240.html">
<img src="{{asset('zealer_files/7e2a68b931f5f3cbba9d0fb8e1.jpg')}}" alt="「科技相对论」体育科学“水很深”，只是很多人没意识到">
<span class="list_cover" style="opacity: 0.346751;"></span>
<span class="left_line" style="opacity: 0.433439; left: 99.1022px;"></span>
<span class="right_line" style="opacity: 0.433439; right: 99.1022px;"></span>
<span class="list_play" style="opacity: 0.433439; top: 11.3312px;">播放</span>
</a>
<p>
「科技相对论」体育科学“水很深”，...</p>
</li>
 
<li totalnum="18">
<a href="http://www.zealer.com/post/238.html">
<img src="{{asset('zealer_files/1655cc81c09c4b364bdedd9cc5.jpg')}}" alt="「科技相对论」科幻：瞎想容易靠谱难">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
「科技相对论」科幻：瞎想容易靠谱难</p>
</li>
 
<li totalnum="18">
<a href="http://www.zealer.com/post/236.html">
<img src="{{asset('zealer_files/600f31ad53a80b2f3f617bbf19.jpg')}}" alt=" 「科技相对论」电子竞技，是游戏也是生意">
<span class="list_cover" style="opacity: 0;"></span>
<span class="left_line" style="opacity: 0; left: 90px;"></span>
<span class="right_line" style="opacity: 0; right: 90px;"></span>
<span class="list_play" style="opacity: 0; top: 20px;">播放</span>
</a>
<p>
 「科技相对论」电子竞技，是游戏也是...</p>
</li>
 
<li totalnum="18">
<a href="http://www.zealer.com/post/234.html">
<img src="{{asset('zealer_files/c409d552315b0d9dcf485719c1.jpg')}}" alt="「科技相对论」中国式众筹">
<span class="list_cover" style="opacity: 0;"></span>
<span class="left_line" style="opacity: 0; left: 90px;"></span>
<span class="right_line" style="opacity: 0; right: 90px;"></span>
<span class="list_play" style="opacity: 0; top: 20px;">播放</span>
</a>
<p>
「科技相对论」中国式众筹</p>
</li>
 
<li totalnum="18">
<a href="http://www.zealer.com/post/229.html">
<img src="{{asset('zealer_files/fbd37bfc96ff2960894a3730ef.jpg')}}" alt="「科技相对论」被玩坏的智能化">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
「科技相对论」被玩坏的智能化</p>
</li>
 
<li totalnum="18">
<a href="http://www.zealer.com/post/225.html">
<img src="{{asset('zealer_files/b06fb8aba4a4993a07e3242b76.jpg')}}" alt="「科技相对论」库克，苹果的罪人还是救星">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
「科技相对论」库克，苹果的罪人还是...</p>
</li>
 
<li totalnum="18">
<a href="http://www.zealer.com/post/223.html">
<img src="{{asset('zealer_files/0ab04a109f98938003000da5c0.jpg')}}" alt="「科技相对论」小众产品复活指南 ">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
「科技相对论」小众产品复活指南 </p>
</li>
 
<li totalnum="18">
<a href="http://www.zealer.com/post/222.html">
<img src="{{asset('zealer_files/20e3a72cbd5885120efb488918.jpg')}}" alt="「科技相对论」草根之上，土豪之下的特斯拉">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
「科技相对论」草根之上，土豪之下的...</p>
</li>
 
<li totalnum="18">
<a href="http://www.zealer.com/post/220.html">
<img src="{{asset('zealer_files/124c8419cdf3f38bc75e71463f.jpg')}}" alt="「ZEALER X 爱奇艺」科技相对论：索尼帝国启示录">
<span class="list_cover" style="opacity: 0;"></span>
<span class="left_line" style="opacity: 0; left: 90px;"></span>
<span class="right_line" style="opacity: 0; right: 90px;"></span>
<span class="list_play" style="opacity: 0; top: 20px;">播放</span>
</a>
<p>
科技相对论：索尼帝国启示录</p>
</li>
 
<li totalnum="18">
<a href="http://www.zealer.com/post/160.html">
<img src="{{asset('zealer_files/d86448ce18547a537f4fa33bae.jpg')}}" alt="Shawn Talk 第七期 Apple Watch 的定价策略">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
Shawn Talk 第七期 Apple Watch 的定...</p>
</li>
 
<li totalnum="18">
<a href="http://www.zealer.com/post/150.html">
<img src="{{asset('zealer_files/3e2f19412c12c7fc1ddc7c6918.jpg')}}" alt="Shawn Talk 第六期 KINDLE PAPERWHITE2">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
Shawn Talk 第六期 KINDLE PAPERWHITE...</p>
</li>
 
<li totalnum="18">
<a href="http://www.zealer.com/post/147.html">
<img src="{{asset('zealer_files/499053caa548a46d650e8fda06.jpg')}}" alt="「ZEALER出品」Shawn Talk 第五期 OFFICE TOUR">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
Shawn Talk 第五期 OFFICE TOUR</p>
</li>
 
<li totalnum="18">
<a href="http://www.zealer.com/post/140.html">
<img src="{{asset('zealer_files/2bb10ae7b23270b9137adb28af.jpg')}}" alt="Shawn Talk 第四期 Apple Watch 和可穿戴设备">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
Shawn Talk 第四期 Apple Watch 和可...</p>
</li>
 
<li totalnum="18">
<a href="http://www.zealer.com/post/23.html">
<img src="{{asset('zealer_files/33e1fcac6fbb94eec5c4869db1.jpg')}}" alt="Shawn Talk 第三期">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
Shawn Talk 第三期</p>
</li>
 
<li totalnum="18">
<a href="http://www.zealer.com/post/20.html">
<img src="{{asset('zealer_files/a35a6a22d01fc14729e36a1c74.jpg')}}" alt="Shawn Talk 第二期">
<span class="list_cover" style="opacity: 0;"></span>
<span class="left_line" style="opacity: 0; left: 90px;"></span>
<span class="right_line" style="opacity: 0; right: 90px;"></span>
<span class="list_play" style="opacity: 0; top: 20px;">播放</span>
</a>
<p>
Shawn Talk 第二期</p>
</li>
 
<li totalnum="18">
<a href="http://www.zealer.com/post/19.html">
<img src="{{asset('zealer_files/2c25f2bb22b08f96d415521c1a.jpg')}}" alt="Shawn Talk 第一期">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
Shawn Talk 第一期</p>
</li>

</ul>
 @endsection
