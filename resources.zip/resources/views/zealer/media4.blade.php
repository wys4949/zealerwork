@extends('zealer.same')
@section('content')

<div class="media_content">
<h2 class="hand_title">ZEALER 酷品</h2>
<p class="hand_recommend">2 分钟带你玩遍天下新奇硬件！</p>
<p class="=&quot;hand_tag&quot;">热门标签</p>
<span class="hand_btn">
<a class="btn_active" href="javascript:;" cid="8" tid="0">最新</a>
</span>
<ul class="hand_video">
 
<li totalnum="22">
<a href="http://www.zealer.com/post/472.html">
<img src="{{asset('zealer_files/e714762fe75a14b5c4f45a2225.jpg')}}" alt="「ZEALER | 酷品」简单好玩的全景相机 Insta 360">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
简单好玩的全景相机 Insta 360</p>
</li>
 
<li totalnum="22">
<a href="http://www.zealer.com/post/470.html">
<img src="{{asset('zealer_files/1da6dc5e63825900cec1cdf311.jpg')}}" alt="「ZEALER | 酷品」银河战甲 无穷我的乐趣！">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
银河战甲 无穷我的乐趣！</p>
</li>
 
<li totalnum="22">
<a href="http://www.zealer.com/post/467.html">
<img src="{{asset('zealer_files/60d5dd546aa92cfb5fa7848b39.jpg')}}" alt="「ZEALER | 酷品」价格实惠，功能全面的 bong3 HR 手环">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
价格实惠，功能全面的 bong3 HR 手环</p>
</li>
 
<li totalnum="22">
<a href="http://www.zealer.com/post/465.html">
<img src="{{asset('zealer_files/519771939d6e94308b2ed174b3.jpg')}}" alt="「ZEALER | 酷品」触摸未来 HTC Vive ">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
触摸未来 HTC Vive </p>
</li>
 
<li totalnum="22">
<a href="http://www.zealer.com/post/462.html">
<img src="{{asset('zealer_files/9836a9a1ed2864578ac3eeba2b.jpg')}}" alt="「ZEALER | 酷品」你的移动影院--嗨镜">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
你的移动影院--嗨镜</p>
</li>
 
<li totalnum="22">
<a href="http://www.zealer.com/post/458.html">
<img src="{{asset('zealer_files/4087bca50687731ae5c765b5e1.jpg')}}" alt="「ZEALER | 酷品」GOFree 蓝牙音箱「粗暴」体验">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
GOFree 蓝牙音箱体验</p>
</li>
 
<li totalnum="22">
<a href="http://www.zealer.com/post/455.html">
<img src="{{asset('zealer_files/81a36328d15d86ebb5f5932fad.jpg')}}" alt="「ZEALER | 酷品」出门好助手，小米电助力单车">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
出门好助手，小米电助力单车</p>
</li>
 
<li totalnum="22">
<a href="http://www.zealer.com/post/454.html">
<img src="{{asset('zealer_files/d6df5f76f2bfb4162420c31235.jpg')}}" alt="「ZEALER | 酷品」微软爸爸的黑科技 HoloLens 未来体验">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
微软爸爸的黑科技 HoloLens 未来体验</p>
</li>
 
<li totalnum="22">
<a href="http://www.zealer.com/post/447.html">
<img src="{{asset('zealer_files/a2efc4305612c4c2dafd5e2297.jpg')}}" alt="「ZEALER | 酷品」软萌桌面风扇">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
软萌桌面风扇</p>
</li>
 
<li totalnum="22">
<a href="http://www.zealer.com/post/445.html">
<img src="{{asset('zealer_files/905801ffabbd6d8d0954e2116a.jpg')}}" alt="「ZEALER | 酷品」360 巴迪龙儿童手表5S">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
360 巴迪龙儿童手表5S</p>
</li>
 
<li totalnum="22">
<a href="http://www.zealer.com/post/440.html">
<img src="{{asset('zealer_files/1091f077cb9f09922cc3355930.jpg')}}" alt="「ZEALER | 酷品」小米台灯 简约实用派">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
小米台灯 简约实用派</p>
</li>
 
<li totalnum="22">
<a href="http://www.zealer.com/post/379.html">
<img src="{{asset('zealer_files/99b183cd072feb0f14b09ede26.jpg')}}" alt="「ZEALER | 酷品」规范健身动作，智能哑铃帮到你">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
规范健身动作，智能哑铃帮到你</p>
</li>
 
<li totalnum="22">
<a href="http://www.zealer.com/post/370.html">
<img src="{{asset('zealer_files/6e32ad65525fe857e9ab19712c.jpg')}}" alt="「ZEALER | 酷品」上手简单，可玩性强！Parrot迷你无人机带你飞">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
上手简单，可玩性强！Parrot迷你无人...</p>
</li>
 
<li totalnum="22">
<a href="http://www.zealer.com/post/367.html">
<img src="{{asset('zealer_files/0d61609fb0695bdffb7fea84d6.jpg')}}" alt="Jumping Sumo 智能遥控车">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
Jumping Sumo 智能遥控车</p>
</li>
 
<li totalnum="22">
<a href="http://www.zealer.com/post/362.html">
<img src="{{asset('zealer_files/705890c5d6ed806ad0ba06aec6.jpg')}}" alt="「ZEALER | 酷品」Gear 360 给你的环形享受">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
Gear 360 给你的环形享受</p>
</li>
 
<li totalnum="22">
<a href="http://www.zealer.com/post/361.html">
<img src="{{asset('zealer_files/816714cd7426a0dc0cb42363fd.jpg')}}" alt="「ZEALER | 酷品」讨人喜爱的多彩「萌灯」">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
讨人喜爱的多彩</p>
</li>
 
<li totalnum="22">
<a href="http://www.zealer.com/post/360.html">
<img src="{{asset('zealer_files/c0b777098f5f74576712c5764f.jpg')}}" alt="「ZEALER | 酷品」愚大宝扫地机器人">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
愚大宝扫地机器人</p>
</li>
 
<li totalnum="22">
<a href="http://www.zealer.com/post/358.html">
<img src="{{asset('zealer_files/94fb2c16017e9edfc7e41f7637.jpg')}}" alt="「ZEALER | 酷品」Bastron玻璃键盘">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
Bastron玻璃键盘</p>
</li>
 
<li totalnum="22">
<a href="http://www.zealer.com/post/356.html">
<img src="{{asset('zealer_files/55314e45a6ffddc91790cb828d.jpg')}}" alt="「ZEALER | 酷品」eyemore 相机带你飞">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
eyemore 相机带你飞</p>
</li>
 
<li totalnum="22">
<a href="http://www.zealer.com/post/352.html">
<img src="{{asset('zealer_files/9bb15e799e99290642957acdd2.jpg')}}" alt="「ZEALER | 酷品」方糖音箱，你萌化了没？">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
方糖音箱，你萌化了没？</p>
</li>
 
<li totalnum="22">
<a href="http://www.zealer.com/post/351.html">
<img src="{{asset('zealer_files/3f36b7950b3c664477855ed2ad.jpg')}}" alt="「ZEALER | 酷品」会跳小苹果的机器人">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
会跳小苹果的机器人</p>
</li>

</ul>
 @endsection
