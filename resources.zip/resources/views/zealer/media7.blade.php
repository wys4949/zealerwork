@extends('zealer.same')
@section('content')

<div class="media_content">
<h2 class="hand_title">UPPER</h2>
<p class="hand_recommend"></p>
<p class="=&quot;hand_tag&quot;">热门标签</p>
<span class="hand_btn">
<a class="btn_active" href="javascript:;" cid="11" tid="0">最新</a>
</span>
<ul class="hand_video">
 
<li totalnum="1">
<a href="http://www.zealer.com/post/459.html">
<img src="{{asset('zealer_files/3d5e5d6ca87da3e5b742917129.jpg')}}" alt="「ZEALER｜UPPER」机器人永不为奴！格斗机器人GANKER诞生记">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
机器人永不为奴！格斗机器人GANKER诞...</p>
</li>

</ul>
 @endsection