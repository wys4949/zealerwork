@extends('zealer.same')
@section('content')

<div class="media_content">
<h2 class="hand_title">硬件测评</h2>
<p class="hand_recommend"></p>
<p class="=&quot;hand_tag&quot;">热门标签</p>
<span class="hand_btn">
<a class="btn_active" href="javascript:;" cid="1" tid="0">最新</a>
</span>
<ul class="hand_video">
 
<li totalnum="144">
<a href="http://www.zealer.com/post/382.html">
<img src="{{asset('zealer_files/33c9fb3214624a793cc54a96d8.jpg')}}" alt="「ZEALER 出品」vivo X7 上手">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
vivo X7 上手</p>
</li>
 
<li totalnum="144">
<a href="http://www.zealer.com/post/363.html">
<img src="{{asset('zealer_files/d760e965e9dc13081963e01284.jpg')}}" alt="「ZEALER 出品」HTC 10 测评">
<span class="list_cover" style="opacity: 0.00521369;"></span>
<span class="left_line" style="opacity: 0.00651712; left: 90.1369px;"></span>
<span class="right_line" style="opacity: 0.00651712; right: 90.1369px;"></span>
<span class="list_play" style="opacity: 0.00651712; top: 19.8696px;">播放</span>
</a>
<p>
HTC 10 测评</p>
</li>
 
<li totalnum="144">
<a href="http://www.zealer.com/post/337.html">
<img src="{{asset('zealer_files/b551cde664eddfa4e1506457b0.jpg')}}" alt="「好奇辣么大」“深度测评”  200 块廉价手机">
<span class="list_cover" style="opacity: 0;"></span>
<span class="left_line" style="opacity: 0; left: 90px;"></span>
<span class="right_line" style="opacity: 0; right: 90px;"></span>
<span class="list_play" style="opacity: 0; top: 20px;">播放</span>
</a>
<p>
“深度测评”  200 块廉价手机</p>
</li>
 
<li totalnum="144">
<a href="http://www.zealer.com/post/327.html">
<img src="{{asset('zealer_files/ff2a5c32ab70774cc86865e139.jpg')}}" alt="LG G5 测评">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
LG G5 测评</p>
</li>
 
<li totalnum="144">
<a href="http://www.zealer.com/post/323.html">
<img src="{{asset('zealer_files/facd511cdb36e4534bc46477e2.jpg')}}" alt="三星 Galaxy C5 上手">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
三星 Galaxy C5 上手</p>
</li>
 
<li totalnum="144">
<a href="http://www.zealer.com/post/311.html">
<img src="{{asset('zealer_files/3c1c72556a0ad0b2f4bb220246.jpg')}}" alt="小米 Max 上手">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
小米 Max 上手</p>
</li>
 
<li totalnum="144">
<a href="http://www.zealer.com/post/305.html">
<img src="{{asset('zealer_files/0ece104d7b1dc4841361165320.jpg')}}" alt="金立 S8 &amp; W909 上手">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
金立&nbsp;S8 &amp; W909&nbsp;上手</p>
</li>
 
<li totalnum="144">
<a href="http://www.zealer.com/post/303.html">
<img src="{{asset('zealer_files/7aca90f998ebbb2e2a38773499.jpg')}}" alt="亚马逊 Kindle Oasis 上手">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
亚马逊 Kindle Oasis 上手</p>
</li>
 
<li totalnum="144">
<a href="http://www.zealer.com/post/301.html">
<img src="{{asset('zealer_files/23c3ae0e3c4857ad8ed8004021.jpg')}}" alt="联想 ZUK Z2 Pro 上手直播版">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
联想 ZUK Z2 Pro 上手直播版</p>
</li>
 
<li totalnum="144">
<a href="http://www.zealer.com/post/300.html">
<img src="{{asset('zealer_files/481db690eeda5e3bc4c8445d43.jpg')}}" alt="华为 P9 上手">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
华为 P9 上手</p>
</li>
 
<li totalnum="144">
<a href="http://www.zealer.com/post/295.html">
<img src="{{asset('zealer_files/d7bdaafff25915aa917f5b857a.jpg')}}" alt="三星 Galaxy S7 edge｜S7 测评">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
三星 Galaxy S7 edge｜S7 测评</p>
</li>
 
<li totalnum="144">
<a href="http://www.zealer.com/post/289.html">
<img src="{{asset('zealer_files/af244a9348cf2cdb6252cb2b26.jpg')}}" alt="真假  iPhone SE 拆了才知道">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
真假 &nbsp;iPhone SE&nbsp;拆了才知道</p>
</li>
 
<li totalnum="144">
<a href="http://www.zealer.com/post/285.html">
<img src="{{asset('zealer_files/3c9299ca5f25d2cd669e6842d5.jpg')}}" alt="魅蓝 note 3 上手">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
魅蓝 note 3 上手</p>
</li>
 
<li totalnum="144">
<a href="http://www.zealer.com/post/282.html">
<img src="{{asset('zealer_files/fe853397b7caed5534ec10c25e.jpg')}}" alt="iPhone SE 上手">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
iPhone SE 上手</p>
</li>
 
<li totalnum="144">
<a href="http://www.zealer.com/post/277.html">
<img src="{{asset('zealer_files/c4bcf03a4ce00e7a8d85bbb79e.jpg')}}" alt="小米 MI5 测评">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
小米 MI5&nbsp;测评</p>
</li>
 
<li totalnum="144">
<a href="http://www.zealer.com/post/271.html">
<img src="{{asset('zealer_files/f210b07e3a0a6bff39024caf2b.jpg')}}" alt="OPPO R9 上手">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
OPPO R9 上手</p>
</li>
 
<li totalnum="144">
<a href="http://www.zealer.com/post/268.html">
<img src="{{asset('zealer_files/764f0fe422d4464fe6ece09e4c.jpg')}}" alt="HUAWEI Mate 8 测评">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
HUAWEI Mate 8 测评</p>
</li>
 
<li totalnum="144">
<a href="http://www.zealer.com/post/266.html">
<img src="{{asset('zealer_files/7033d1721091c838af45afea53.jpg')}}" alt="vivo Xplay5 上手">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
vivo Xplay5 上手</p>
</li>
 
<li totalnum="144">
<a href="http://www.zealer.com/post/263.html">
<img src="{{asset('zealer_files/b210ea3838f3bd914c42e8cc9f.jpg')}}" alt="小米 5 上手体验 ">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
小米 5 上手体验 </p>
</li>
 
<li totalnum="144">
<a href="http://www.zealer.com/post/262.html">
<img src="{{asset('zealer_files/0419d470d11e353763aee8d244.jpg')}}" alt="三星 Galaxy S7 edge 上手体验">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
三星 Galaxy S7 edge 上手体验</p>
</li>
 
<li totalnum="144">
<a href="http://www.zealer.com/post/257.html">
<img src="{{asset('zealer_files/ccf55ae435625008d7a84d9a9f.jpg')}}" alt="Smartisan T2 测评">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
Smartisan T2 测评</p>
</li>

</ul>
 @endsection
