@extends('zealer.same')
@section('content')

<div class="media_content">
<h2 class="hand_title">智慧生活</h2>
<p class="hand_recommend">智慧生活，来源于智慧的科技产品</p>
<p class="=&quot;hand_tag&quot;">热门标签</p>
<span class="hand_btn">
<a class="btn_active" href="javascript:;" cid="7" tid="0">最新</a>
</span>
<ul class="hand_video">
 
<li totalnum="7">
<a href="http://www.zealer.com/post/355.html">
<img src="{{asset('zealer_files/dbf80e1ccbc47313636281a1d0.jpg')}}" alt="海尔迪士尼定制冰箱体验">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
海尔迪士尼定制冰箱体验</p>
</li>
 
<li totalnum="7">
<a href="http://www.zealer.com/post/349.html">
<img src="{{asset('zealer_files/5eab627aa931a51aacd6f3d4a4.jpg')}}" alt="三星品式多门冰箱 -- “品道·智宴”初体验">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
三星品式多门冰箱 -- “品道·智宴”...</p>
</li>
 
<li totalnum="7">
<a href="http://www.zealer.com/post/341.html">
<img src="{{asset('zealer_files/4319313b129933f02996308ec1.jpg')}}" alt="三星滚筒洗衣机--“蝶窗·蓝水晶”初体验">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
三星滚筒洗衣机--“蝶窗·蓝水晶”初...</p>
</li>
 
<li totalnum="7">
<a href="http://www.zealer.com/post/333.html">
<img src="{{asset('zealer_files/d7f645e510a7b11825fc72f9fb.jpg')}}" alt="「ZEALER 出品」飞利浦 S8860 电须刀体验">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
飞利浦 S8860 电须刀体验</p>
</li>
 
<li totalnum="7">
<a href="http://www.zealer.com/post/331.html">
<img src="{{asset('zealer_files/5b72e0ed2bb309d8314ffe9998.jpg')}}" alt="三星曲面量子点电视--KS9800初体验">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
三星曲面量子点电视--KS9800初体验</p>
</li>
 
<li totalnum="7">
<a href="http://www.zealer.com/post/326.html">
<img src="{{asset('zealer_files/9ae7539c1313eff2257b71c172.jpg')}}" alt="一万块的空气净化器凭啥那么贵？">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
一万块的空气净化器凭啥那么贵？</p>
</li>
 
<li totalnum="7">
<a href="http://www.zealer.com/post/309.html">
<img src="{{asset('zealer_files/619d2bd9ceee2233edfdb4aaa4.jpg')}}" alt="当 ZEALER 遇见特斯拉 Model X">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
当 ZEALER 遇见特斯拉 Model X</p>
</li>

</ul>
 @endsection
