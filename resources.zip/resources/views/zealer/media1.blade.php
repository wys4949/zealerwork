@extends('zealer.same')
@section('content')

<div class="media_content">
<h2 class="hand_title">手机简评</h2>
<p class="hand_recommend"></p>
<p class="=&quot;hand_tag&quot;">热门标签</p>
<span class="hand_btn">
<a class="btn_active" href="javascript:;" cid="9" tid="0">最新</a>
</span>
<ul class="hand_video">
 
<li totalnum="56">
<a href="http://www.zealer.com/post/441.html">
<img src="{{asset('zealer_files/e4529feb8cbcbf96fa3abf678b.jpg')}}" alt="「ZEALER 简评」一加手机 3">
<span class="list_cover" style="opacity: 0;"></span>
<span class="left_line" style="opacity: 0; left: 90px;"></span>
<span class="right_line" style="opacity: 0; right: 90px;"></span>
<span class="list_play" style="opacity: 0; top: 20px;">播放</span>
</a>
<p>
「ZEALER 简评」一加手机 3</p>
</li>
 
<li totalnum="56">
<a href="http://www.zealer.com/post/439.html">
<img src="{{asset('zealer_files/a362d5be3bccf16835f3b75802.jpg')}}" alt="「ZEALER 简评」魅族 Pro 6">
<span class="list_cover" style="opacity: 0.221209;"></span>
<span class="left_line" style="opacity: 0.276511; left: 95.8067px;"></span>
<span class="right_line" style="opacity: 0.276511; right: 95.8067px;"></span>
<span class="list_play" style="opacity: 0.276511; top: 14.4698px;">播放</span>
</a>
<p>
「ZEALER 简评」魅族 Pro 6</p>
</li>
 
<li totalnum="56">
<a href="http://www.zealer.com/post/438.html">
<img src="{{asset('zealer_files/f58f49c30c719a3d9200245599.jpg')}}" alt="「ZEALER 简评」魅族 Pro 5">
<span class="list_cover" style="opacity: 0.233002;"></span>
<span class="left_line" style="opacity: 0.291252; left: 96.1162px;"></span>
<span class="right_line" style="opacity: 0.291252; right: 96.1162px;"></span>
<span class="list_play" style="opacity: 0.291252; top: 14.175px;">播放</span>
</a>
<p>
「ZEALER 简评」魅族 Pro 5</p>
</li>
 
<li totalnum="56">
<a href="http://www.zealer.com/post/437.html">
<img src="{{asset('zealer_files/2cf7ff3450458a8a88ffb36cb5.jpg')}}" alt="「ZEALER 简评」Moto X Style">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
「ZEALER 简评」Moto X Style</p>
</li>
 
<li totalnum="56">
<a href="http://www.zealer.com/post/436.html">
<img src="{{asset('zealer_files/13d35defaa599a6418d98452ca.jpg')}}" alt="「ZEALER 简评」Moto X 极">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
「ZEALER 简评」Moto X 极</p>
</li>
 
<li totalnum="56">
<a href="http://www.zealer.com/post/435.html">
<img src="{{asset('zealer_files/d84bb65144465a8b1cd80331ea.jpg')}}" alt="「ZEALER 简评」三星 Galaxy Note Edge">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
「ZEALER 简评」三星 Galaxy Note Edg...</p>
</li>
 
<li totalnum="56">
<a href="http://www.zealer.com/post/434.html">
<img src="{{asset('zealer_files/ae4c277498403266c8f6758657.jpg')}}" alt="「ZEALER 简评」三星 Galaxy A9">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
「ZEALER 简评」三星 Galaxy A9</p>
</li>
 
<li totalnum="56">
<a href="http://www.zealer.com/post/433.html">
<img src="{{asset('zealer_files/071cbcf3464da3448693cd4006.jpg')}}" alt="「ZEALER 简评」三星 Galaxy A8">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
「ZEALER 简评」三星 Galaxy A8</p>
</li>
 
<li totalnum="56">
<a href="http://www.zealer.com/post/432.html">
<img src="{{asset('zealer_files/71d5f78c3488b4b099d60d0e47.jpg')}}" alt="「ZEALER 简评」三星 Galaxy A7">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
「ZEALER 简评」三星 Galaxy A7</p>
</li>
 
<li totalnum="56">
<a href="http://www.zealer.com/post/431.html">
<img src="{{asset('zealer_files/428a40d7f7399a4ca8395c7fc9.jpg')}}" alt="「ZEALER 简评」三星 Galaxy A5">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
「ZEALER 简评」三星 Galaxy A5</p>
</li>
 
<li totalnum="56">
<a href="http://www.zealer.com/post/430.html">
<img src="{{asset('zealer_files/c1cb9d5734a6b2ad1a420dbe8e.jpg')}}" alt="「ZEALER 简评」三星 Galaxy J5 &amp; J7">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
「ZEALER 简评」三星 Galaxy J5 &amp;...</p>
</li>
 
<li totalnum="56">
<a href="http://www.zealer.com/post/429.html">
<img src="{{asset('zealer_files/d4fa28b5ae9f74b024e62ecb70.jpg')}}" alt="「ZEALER 简评」三星 Galaxy On5 &amp; On7">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
「ZEALER 简评」三星 Galaxy On5 &amp;...</p>
</li>
 
<li totalnum="56">
<a href="http://www.zealer.com/post/428.html">
<img src="{{asset('zealer_files/fe70511693c12fbf5f71914377.jpg')}}" alt="「ZEALER 简评」华为 P8 Max">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
「ZEALER 简评」华为 P8 Max</p>
</li>
 
<li totalnum="56">
<a href="http://www.zealer.com/post/427.html">
<img src="{{asset('zealer_files/a5b942ffec134e00818ff16063.jpg')}}" alt="「ZEALER 简评」华为 P8 青春版">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
「ZEALER 简评」华为 P8 青春版</p>
</li>
 
<li totalnum="56">
<a href="http://www.zealer.com/post/426.html">
<img src="{{asset('zealer_files/34934699a69eb0904e70896a9b.jpg')}}" alt="「ZEALER 简评」荣耀 6 Plus">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
「ZEALER 简评」荣耀 6 Plus</p>
</li>
 
<li totalnum="56">
<a href="http://www.zealer.com/post/425.html">
<img src="{{asset('zealer_files/a0ffda648fd7d2c89b969898dd.jpg')}}" alt="「ZEALER 简评」荣耀畅玩 4X &amp; 4C">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
「ZEALER 简评」荣耀畅玩 4X &amp; 4C</p>
</li>
 
<li totalnum="56">
<a href="http://www.zealer.com/post/424.html">
<img src="{{asset('zealer_files/d7b4111dfd9409b783718261e1.jpg')}}" alt="「ZEALER 简评」华为麦芒 4">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
「ZEALER 简评」华为麦芒 4</p>
</li>
 
<li totalnum="56">
<a href="http://www.zealer.com/post/423.html">
<img src="{{asset('zealer_files/ec086e3e3191dd30e32086178a.jpg')}}" alt="「ZEALER 简评」小米 4S">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
「ZEALER 简评」小米 4S</p>
</li>
 
<li totalnum="56">
<a href="http://www.zealer.com/post/422.html">
<img src="{{asset('zealer_files/1e1f067846cbe0967476fbd987.jpg')}}" alt="「ZEALER 简评」小米 4C">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
「ZEALER 简评」小米 4C</p>
</li>
 
<li totalnum="56">
<a href="http://www.zealer.com/post/421.html">
<img src="{{asset('zealer_files/f087e07a7e58bfdc156d833b5e.jpg')}}" alt="「ZEALER 简评」红米 3">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
「ZEALER 简评」红米 3</p>
</li>
 
<li totalnum="56">
<a href="http://www.zealer.com/post/420.html">
<img src="{{asset('zealer_files/668998043cd7ca190eb8ca744e.jpg')}}" alt="「ZEALER 简评」索尼 Xperia Z5 Compact">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
「ZEALER 简评」索尼 Xperia Z5 Compa...</p>
</li>

</ul>
 @endsection
