@extends('zealer.same')
@section('content')

<div class="media_content">
<h2 class="hand_title">行业报道</h2>
<p class="hand_recommend"></p>
<p class="=&quot;hand_tag&quot;">热门标签</p>
<span class="hand_btn">
<a class="btn_active" href="javascript:;" cid="5" tid="0">最新</a>
</span>
<ul class="hand_video">
 
<li totalnum="32">
<a href="http://www.zealer.com/post/443.html">
<img src="{{asset('zealer_files/2019dea623ced9e77a1dc0e99a.jpg')}}" alt="直击vivo X7/ X7 Plus发布现场——王自如对话vivo副总裁冯磊">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
直击vivo X7/ X7 Plus发布现场——王...</p>
</li>
 
<li totalnum="32">
<a href="http://www.zealer.com/post/345.html">
<img src="{{asset('zealer_files/435b70fa1c37ad6315e3af4d8f.jpg')}}" alt="「ZEALER | HERE」隔壁老王惊现一加3 发布会  Home 键逼疯了“强迫症”！">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
隔壁老王惊现一加3 发布会  Home 键逼...</p>
</li>
 
<li totalnum="32">
<a href="http://www.zealer.com/post/342.html">
<img src="{{asset('zealer_files/3658450a2b9048030c67d3cc5d.jpg')}}" alt="「ZEALER | HERE」OPPO R9 超人气夏日派对：巴萨定制版全程直击">
<span class="list_cover" style="opacity: 0.710198;"></span>
<span class="left_line" style="opacity: 0.887748; left: 108.643px;"></span>
<span class="right_line" style="opacity: 0.887748; right: 108.643px;"></span>
<span class="list_play" style="opacity: 0.887748; top: 2.24504px;">播放</span>
</a>
<p>
OPPO R9 超人气夏日派对：巴萨定制版...</p>
</li>
 
<li totalnum="32">
<a href="http://www.zealer.com/post/340.html">
<img src="{{asset('zealer_files/23dd106769642be0383bd61d7c.jpg')}}" alt="「ZEALER | HERE」美图 M6 手机发布会：男人的泡妞神器，女人的颜值救星！">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
美图 M6 手机发布会：男人的泡妞神器...</p>
</li>
 
<li totalnum="32">
<a href="http://www.zealer.com/post/332.html">
<img src="{{asset('zealer_files/b56ed26c85f61442b59ba4cfde.jpg')}}" alt="「ZEALER | HERE」跑车的外表轿车的心，这样的装逼方式能让你满意吗？">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
跑车的外表轿车的心，这样的装逼方式...</p>
</li>
 
<li totalnum="32">
<a href="http://www.zealer.com/post/325.html">
<img src="{{asset('zealer_files/527a0a0d9c9352765362c68aa9.jpg')}}" alt="听 C(SEI) 说 SAMSUNG">
<span class="list_cover" style="opacity: 0;"></span>
<span class="left_line" style="opacity: 0; left: 90px;"></span>
<span class="right_line" style="opacity: 0; right: 90px;"></span>
<span class="list_play" style="opacity: 0; top: 20px;">播放</span>
</a>
<p>
听 C(SEI) 说 SAMSUNG</p>
</li>
 
<li totalnum="32">
<a href="http://www.zealer.com/post/319.html">
<img src="{{asset('zealer_files/8c80676a06efeddd26df271513.jpg')}}" alt="1 分钟带你看科沃斯发布会">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
1 分钟带你看科沃斯发布会</p>
</li>
 
<li totalnum="32">
<a href="http://www.zealer.com/post/318.html">
<img src="{{asset('zealer_files/a43a37732cc6239a86a0284c3b.jpg')}}" alt="「SOC:探秘者」探秘一加手机背后的故事">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
「SOC:探秘者」探秘一加手机背后的故...</p>
</li>
 
<li totalnum="32">
<a href="http://www.zealer.com/post/316.html">
<img src="{{asset('zealer_files/3665d0abe614164e54702a6b51.jpg')}}" alt="再次定义手机的会是它吗？王自如对话联想集团高级副总裁陈旭东">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
再次定义手机的会是它吗？王自如对话...</p>
</li>
 
<li totalnum="32">
<a href="http://www.zealer.com/post/315.html">
<img src="{{asset('zealer_files/5c915ac3b18e8166962b30f2db.jpg')}}" alt="周源、王自如、洪晃等大咖云集盐Club，ZEALER 3分钟带你看现场">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
周源、王自如、洪晃等大咖云集盐Club...</p>
</li>
 
<li totalnum="32">
<a href="http://www.zealer.com/post/312.html">
<img src="{{asset('zealer_files/ff0e92bfe242a76021d15ae3eb.jpg')}}" alt="王自如对话雷军">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
王自如对话雷军</p>
</li>
 
<li totalnum="32">
<a href="http://www.zealer.com/post/302.html">
<img src="{{asset('zealer_files/13729ce113f21f3ab50bd9500c.jpg')}}" alt="1分钟了解九个“全球第一”的ZUK Z2 Pro">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
1分钟了解九个“全球第一”的ZUK Z2 P...</p>
</li>
 
<li totalnum="32">
<a href="http://www.zealer.com/post/294.html">
<img src="{{asset('zealer_files/b593a4ee432ab4074340ecdfee.jpg')}}" alt="续航几个月的 Kindle Oasis 能让你多看一页书么？">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
续航几个月的 Kindle Oasis 能让你多...</p>
</li>
 
<li totalnum="32">
<a href="http://www.zealer.com/post/290.html">
<img src="{{asset('zealer_files/b904458d4bedb9baac5343a35e.jpg')}}" alt="带你 1 分钟看完 魅族 PRO 6 发布会">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
带你 1 分钟看完 魅族 PRO 6 发布会</p>
</li>
 
<li totalnum="32">
<a href="http://www.zealer.com/post/288.html">
<img src="{{asset('zealer_files/eaad3c9bcff7ef56b4ea72cbc2.jpg')}}" alt="和京东 3C 事业部总裁胡胜利聊聊线上 3C 购物体验">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
和京东 3C 事业部总裁胡胜利聊聊线上 ...</p>
</li>
 
<li totalnum="32">
<a href="http://www.zealer.com/post/287.html">
<img src="{{asset('zealer_files/05dc2618d338e3aa2c3a7c1a74.jpg')}}" alt="带你 1 分钟看完京东 3C 发布会">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
带你 1 分钟看完京东 3C 发布会</p>
</li>
 
<li totalnum="32">
<a href="http://www.zealer.com/post/283.html">
<img src="{{asset('zealer_files/6fc5f0850fdfaf25a547f76099.jpg')}}" alt="带你 1 分钟看完 魅蓝note3 发布会 ">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
带你&nbsp;1&nbsp;分钟看完 魅蓝note3&nbsp;发布会...</p>
</li>
 
<li totalnum="32">
<a href="http://www.zealer.com/post/278.html">
<img src="{{asset('zealer_files/80139e84eadf722c395f4749fa.jpg')}}" alt="带你 1 分钟看完小米春季媒体沟通会">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
带你 1 分钟看完小米春季媒体沟通会</p>
</li>
 
<li totalnum="32">
<a href="http://www.zealer.com/post/274.html">
<img src="{{asset('zealer_files/ea229a6f66a35a92b2ca4147ef.jpg')}}" alt="王自如带你 2 分钟看完苹果发布会">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
王自如带你 2 分钟看完苹果发布会</p>
</li>
 
<li totalnum="32">
<a href="http://www.zealer.com/post/272.html">
<img src="{{asset('zealer_files/5f4b018bd69142d779e27fcd8a.jpg')}}" alt="带你 1 分钟看完 OPPO R9 发布会">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
带你 1 分钟看完 OPPO R9 发布会</p>
</li>
 
<li totalnum="32">
<a href="http://www.zealer.com/post/270.html">
<img src="{{asset('zealer_files/f62cd23e77c40ad1b4ba4d338f.jpg')}}" alt="带你 2 分钟看懂最强 VR「htc VIVE」">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
带你 2 分钟看懂最强 VR</p>
</li>

</ul>
 @endsection
