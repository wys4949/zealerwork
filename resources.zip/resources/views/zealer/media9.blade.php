@extends('zealer.same')
@section('content')
<div class="media_content">
<h2 class="hand_title">ZEALER 那些事</h2>
<p class="hand_recommend"></p>
<p class="=&quot;hand_tag&quot;">热门标签</p>
<span class="hand_btn">
<a class="btn_active" href="javascript:;" cid="3" tid="0">最新</a>
</span>
<ul class="hand_video">
 
<li totalnum="17">
<a href="http://www.zealer.com/post/307.html">
<img src="{{asset('zealer_files/f0befac7d7b7a71e841dfa6d21.jpg')}}" alt="王自如 差旅日志 Ⅱ">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
王自如 差旅日志 Ⅱ</p>
</li>
 
<li totalnum="17">
<a href="http://www.zealer.com/post/261.html">
<img src="{{asset('zealer_files/a79b01e5d938d689f143570b22.jpg')}}" alt="2015 探索路上感谢有你">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
2015 探索路上感谢有你</p>
</li>
 
<li totalnum="17">
<a href="http://www.zealer.com/post/221.html">
<img src="{{asset('zealer_files/0bdd8e208909592ad6f25d0e75.jpg')}}" alt="「ZEALER 出品」王自如 差旅日志">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
王自如 差旅日志</p>
</li>
 
<li totalnum="17">
<a href="http://www.zealer.com/post/149.html">
<img src="{{asset('zealer_files/f7ef20db99fd3a6cc6f0319ff3.jpg')}}" alt="LIFE AT ZEALER ">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
LIFE AT ZEALER </p>
</li>
 
<li totalnum="17">
<a href="http://www.zealer.com/post/148.html">
<img src="{{asset('zealer_files/80e74851b8b75f1d7102efcef5.jpg')}}" alt="思想汇报 #4">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
思想汇报 #4</p>
</li>
 
<li totalnum="17">
<a href="http://www.zealer.com/post/126.html">
<img src="{{asset('zealer_files/cb0e3b7ce7a1c6722101f1cb2a.jpg')}}" alt="ZEALER 测评2.0 发布会">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
ZEALER 测评2.0 发布会</p>
</li>
 
<li totalnum="17">
<a href="http://www.zealer.com/post/118.html">
<img src="{{asset('zealer_files/4bf704d8e071253e6fd201779f.jpg')}}" alt="2014 新年特辑">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
2014 新年特辑</p>
</li>
 
<li totalnum="17">
<a href="http://www.zealer.com/post/119.html">
<img src="{{asset('zealer_files/d7c6393e21ddb311b7d71b5ca9.jpg')}}" alt="香港卫视《脸谱》栏目 科技大牛和他的测评世界 下集">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
香港卫视《脸谱》栏目 科技大牛和他的...</p>
</li>
 
<li totalnum="17">
<a href="http://www.zealer.com/post/116.html">
<img src="{{asset('zealer_files/7f284056698e1615eec123e35d.jpg')}}" alt="手机握持姿势有奖调查问卷">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
手机握持姿势有奖调查问卷</p>
</li>
 
<li totalnum="17">
<a href="http://www.zealer.com/post/112.html">
<img src="{{asset('zealer_files/7a3b0027a18ab3317154d789f3.jpg')}}" alt="香港卫视《脸谱》栏目 科技大牛和他的测评世界 上集">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
香港卫视《脸谱》栏目 科技大牛和他的...</p>
</li>
 
<li totalnum="17">
<a href="http://www.zealer.com/post/102.html">
<img src="{{asset('zealer_files/5d29309803c280fde4506a9e15.jpg')}}" alt="新版 ZEALER.COM">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
新版 ZEALER.COM</p>
</li>
 
<li totalnum="17">
<a href="http://www.zealer.com/post/13.html">
<img src="{{asset('zealer_files/2452ed0facc4e5544599e6e0be.jpg')}}" alt="新春特辑 ZEALER Style 之《Z Team行动》">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
新春特辑 ZEALER Style 之《Z Team行...</p>
</li>
 
<li totalnum="17">
<a href="http://www.zealer.com/post/100.html">
<img src="{{asset('zealer_files/7eb27ec95b1c4dfa797d583790.jpg')}}" alt="WHAT&#39;S NEXT 与科技无关">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
WHAT'S NEXT 与科技无关</p>
</li>
 
<li totalnum="17">
<a href="http://www.zealer.com/post/99.html">
<img src="{{asset('zealer_files/94106471fec0ba69c5a0d05723.jpg')}}" alt="陪你看发布会 WWDC 2012">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
陪你看发布会 WWDC 2012</p>
</li>
 
<li totalnum="17">
<a href="http://www.zealer.com/post/94.html">
<img src="{{asset('zealer_files/2d6d23d524ebf8641922b3ce8e.jpg')}}" alt="【周年特辑】视频是怎么炼成的">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
【周年特辑】视频是怎么炼成的</p>
</li>
 
<li totalnum="17">
<a href="http://www.zealer.com/post/64.html">
<img src="{{asset('zealer_files/26f820d32cd9a18013dfde1af0.jpg')}}" alt="与科技无关-Just an Update">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
与科技无关-Just an Update</p>
</li>
 
<li totalnum="17">
<a href="http://www.zealer.com/post/49.html">
<img src="{{asset('zealer_files/16e21f7b6919bbfc43f6a5b2f0.jpg')}}" alt="[周年特集]To Everyone of You">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
[周年特集]To Everyone of You</p>
</li>

</ul>
 @endsection
