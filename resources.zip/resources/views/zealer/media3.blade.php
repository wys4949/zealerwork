@extends('zealer.same')
@section('content')
<div class="media_content">
<h2 class="hand_title">ZEALER | TIPS</h2>
<p class="hand_recommend"></p>
<p class="=&quot;hand_tag&quot;">热门标签</p>
<span class="hand_btn">
<a class="btn_active" href="javascript:;" cid="4" tid="0">最新</a>
</span>
<ul class="hand_video">
 
<li totalnum="68">
<a href="http://www.zealer.com/post/471.html">
<img src="{{asset('zealer_files/0ec5e2fa94229736749f0aa8be.jpg')}}" alt="再见 iOS 9，你好 iOS 10！">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
再见 iOS 9，你好 iOS 10！</p>
</li>
 
<li totalnum="68">
<a href="http://www.zealer.com/post/469.html">
<img src="{{asset('zealer_files/d86725bfeaca81376c7116f48e.jpg')}}" alt="有种噪音能让你睡得更香">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
有种噪音能让你睡得更香</p>
</li>
 
<li totalnum="68">
<a href="http://www.zealer.com/post/468.html">
<img src="{{asset('zealer_files/80878c85501b1e8fe3df44b98b.jpg')}}" alt="「ZEALER | Tips」蓝牙5.0 这次不只是更快更远">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
蓝牙5.0 这次不只是更快更远</p>
</li>
 
<li totalnum="68">
<a href="http://www.zealer.com/post/466.html">
<img src="{{asset('zealer_files/ae6d30f64bb7d7a5b319f969cb.jpg')}}" alt="「ZEALER | Tips」全网不是你想通 想通就能通">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
全网不是你想通 想通就能通</p>
</li>
 
<li totalnum="68">
<a href="http://www.zealer.com/post/463.html">
<img src="{{asset('zealer_files/79bbc348c7d14cf7833f5c6f1e.jpg')}}" alt="「ZEALER | Tips」想在中国玩 Pokemon Go  你应该知道的几件事">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
想在中国玩 Pokemon Go  你应该知道的...</p>
</li>
 
<li totalnum="68">
<a href="http://www.zealer.com/post/461.html">
<img src="{{asset('zealer_files/826563f70e9c39d241268ca2e2.jpg')}}" alt="「ZEALER | Tips」玩游戏网速卡？四招给你的网速做手术！">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
玩游戏网速卡？四招给你的网速做手术...</p>
</li>
 
<li totalnum="68">
<a href="http://www.zealer.com/post/460.html">
<img src="{{asset('zealer_files/b0bc4f0fb96e764f71c919a4fd.jpg')}}" alt="「ZEALER | Tips」VR很爽，可是WE ARE很晕，怎么破？！">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
VR很爽，可是WE ARE很晕，怎么破？！</p>
</li>
 
<li totalnum="68">
<a href="http://www.zealer.com/post/456.html">
<img src="{{asset('zealer_files/ec74b55c834086dbdf44e88a28.jpg')}}" alt="「ZEALER | Tips」手机进水不可怕，就怕机主没文化！">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
手机进水不可怕，就怕机主没文化！</p>
</li>
 
<li totalnum="68">
<a href="http://www.zealer.com/post/453.html">
<img src="{{asset('zealer_files/01e697a9eafdfd0d81f755e803.jpg')}}" alt="「ZEALER | Tips」那些年 学渣们错过的神器">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
那些年 学渣们错过的神器</p>
</li>
 
<li totalnum="68">
<a href="http://www.zealer.com/post/452.html">
<img src="{{asset('zealer_files/db3a17c6b9da72ba98414fef2c.jpg')}}" alt="「ZEALER | Tips」不实名认证 连红包都抢不了？">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
不实名认证 连红包都抢不了？</p>
</li>
 
<li totalnum="68">
<a href="http://www.zealer.com/post/448.html">
<img src="{{asset('zealer_files/dd388faae452f7d0fc4e7877aa.jpg')}}" alt="「ZEALER | Tips」食物落地的「5秒真理」靠谱吗">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
食物落地的靠谱吗</p>
</li>
 
<li totalnum="68">
<a href="http://www.zealer.com/post/446.html">
<img src="{{asset('zealer_files/a1c30f1042a2ce5111da395db9.jpg')}}" alt="「ZEALER | Tips」机票怎么买最便宜！">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
机票怎么买最便宜！</p>
</li>
 
<li totalnum="68">
<a href="http://www.zealer.com/post/444.html">
<img src="{{asset('zealer_files/e0c4b6d0e2896e0ddd05f593fe.jpg')}}" alt="按下快门 处处都是唐人街">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
按下快门 处处都是唐人街</p>
</li>
 
<li totalnum="68">
<a href="http://www.zealer.com/post/442.html">
<img src="{{asset('zealer_files/98e45d609cd0616be9c8a13e71.jpg')}}" alt="你永远叫不醒一个懒床的人 除非有它">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
你永远叫不醒一个懒床的人 除非有它</p>
</li>
 
<li totalnum="68">
<a href="http://www.zealer.com/post/381.html">
<img src="{{asset('zealer_files/c9ebaf2ff2ac6d2ad9d62bd2aa.jpg')}}" alt="连座位都不会选 还去电影院干啥？！">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
连座位都不会选 还去电影院干啥？！</p>
</li>
 
<li totalnum="68">
<a href="http://www.zealer.com/post/371.html">
<img src="{{asset('zealer_files/b708963798473299886197d203.jpg')}}" alt="看完球胖了？这锅欧洲杯，不背！">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
看完球胖了？这锅欧洲杯，不背！</p>
</li>
 
<li totalnum="68">
<a href="http://www.zealer.com/post/368.html">
<img src="{{asset('zealer_files/ff97492c7d9b0f850333224e67.jpg')}}" alt="遇见怪蜀黍 我不「怕」不「怕」啦">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
遇见怪蜀黍 我不「怕」不「怕」啦</p>
</li>
 
<li totalnum="68">
<a href="http://www.zealer.com/post/366.html">
<img src="{{asset('zealer_files/fdf22f2152fb0cd3bab9b83676.jpg')}}" alt="「ZEALER | Tips」歪？妖妖灵嘛？我的 iPhone 被「 劫持」了">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
歪？妖妖灵嘛？我的 iPhone 被了</p>
</li>
 
<li totalnum="68">
<a href="http://www.zealer.com/post/365.html">
<img src="{{asset('zealer_files/325fe1e6b9831f5eed289481ae.jpg')}}" alt="欧洲杯来了！看球和睡觉我都要！">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
欧洲杯来了！看球和睡觉我都要！</p>
</li>
 
<li totalnum="68">
<a href="http://www.zealer.com/post/359.html">
<img src="{{asset('zealer_files/a6cb43a9490dd57de543c55bea.jpg')}}" alt="原来 iPhone 也能自定义铃声">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
原来 iPhone 也能自定义铃声</p>
</li>
 
<li totalnum="68">
<a href="http://www.zealer.com/post/357.html">
<img src="{{asset('zealer_files/679ec689c682577d85b57f3e83.jpg')}}" alt="iOS特辑2.0 说明书是写了 但你看了吗？">
<span class="list_cover"></span>
<span class="left_line"></span>
<span class="right_line"></span>
<span class="list_play">播放</span>
</a>
<p>
iOS特辑2.0 说明书是写了 但你看了吗...</p>
</li>

</ul>
 @endsection
