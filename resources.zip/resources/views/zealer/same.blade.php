<!DOCTYPE html>
<!-- saved from url=(0041)http://www.zealer.com/media?cid=3&index=8 -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <title>ZEALER科技视频_ZEALER</title>
    <meta name="keywords" content="科技视频">
    <meta name="description" content="ZEALER科技视频，包含智能硬件评测视频，有趣的玩机视频和互联网科技大佬专访视频。科技相对论，以及ZEALER那些事，是科技发烧友的垂直门户视频网站。">
    <meta property="qc:admins" content="271622326062514526375">
    <meta name="viewport" content="width=1120">

    <link href="{{asset('zealer_files/libs_98e9c.css')}}" rel="stylesheet" type="text/css">
    <link href="{{asset('zealer_files/global_4eae3726c8.css')}}" rel="stylesheet" type="text/css">
    <link href="{{asset('zealer_files/page_8aeee6bfa3.css')}}" rel="stylesheet" type="text/css">

    <link rel="icon" href="http://www.zealer.com/favicon.ico">
    <script src="{{asset('zealer_files/push.js')}}"></script><script async="" src="{{asset('zealer_files/analytics.js')}}"></script><script src="{{asset('zealer_files/hm.js')}}"></script><script>
        var STATIC_HOST = 'http://static.zealer.com/';
        var STAT_HOST = 'http://stat.wangziru.com/';
        var WWW_HOST = 'http://www.zealer.com/';
    </script>
    <script>
        //移动设备判断
        var isMobile = {
            Android: function() {
                return navigator.userAgent.match(/Android/i) ? true : false;
            },
            BlackBerry: function() {
                return navigator.userAgent.match(/BlackBerry/i) ? true : false;
            },
            iOS: function() {
                return navigator.userAgent.match(/iPhone|iPad|iPod/i) ? true : false;
            },
            Windows: function() {
                return navigator.userAgent.match(/IEMobile/i) ? true : false;
            },
            Phone: function() {
                return navigator.userAgent.match(/Mobile/i) ? true : false;
            },
            any: function() {
                return (isMobile.Android() || isMobile.BlackBerry() || isMobile.Windows() || isMobile.Phone());
            }
        };

        function isIE () {
            var myNav = navigator.userAgent.toLowerCase();
            return (myNav.indexOf('msie') != -1) ? parseInt(myNav.split('msie')[1]) : false;
        };

    </script>
</head>
<body>
<div class="global_cover"></div>

<div class="global_header smallHead">
    <div class="header_inner clear">

        <div class="account_wrap">
            <div class="header_account clear">
                <ul class="account_nav clear">
                    @foreach($title as $t)
                    <li><a class="" href="{{$t->tit_url}}">{{$t->tit_name}}</a></li>
                    @endforeach

                </ul>
                <div class="inner_account">
                    <a href="http://www.zealer.com/search" target="_blank" class="account_search index_icons"></a>
                    <a href="http://www.zealer.com/message?type=discuss" target="_blank" class="account_message">通知
                        <span class="message_num"></span>
                    </a>
                    <a href="http://www.zealer.com/message?type=inbox" target="_blank" class="account_letter">私信
                        <span class="letter_num"></span>
                    </a>
                    <span class="account_user clear">
<a class="img_link clear" href="http://www.zealer.com/personal">
<img class="user_img" src="{{asset('zealer_files/mb_pic30.gif')}}" alt="会员头像">
</a>
<span class="user_active smallHead">
<a href="http://www.zealer.com/personal" class="active_name" rel="nofollow"></a>
<a href="http://www.zealer.com/user/logout" rel="nofollow">退出</a>
</span>
</span>
                    <div class="account_list message_list clear"></div>
                    <div class="account_list sms_list clear">
                    </div>
                </div>
                <div class="inner_login" style="">
                    <a class="login_in global_gaNode" href="http://www.zealer.com/login/?from=index&amp;redirect=http%3A%2F%2Fwww.zealer.com%2Fmedia%3Fcid%3D3%26index%3D8" data-galable="home_header_login">登录</a>
                    <a class="logoutCss global_gaNode" href="http://www.zealer.com/reg?from=Index&amp;redirect=http%3A%2F%2Fwww.zealer.com%2Fmedia%3Fcid%3D3%26index%3D8" data-galable="home_header_reg">注册</a>
                </div>
            </div>
        </div>

        <div class="nav_wrap">
            <a class="inner_logo index_icons global_gaNode" href="http://www.zealer.com/" data-galable="home_header_logo"></a>
            <ul class="inner_nav">
                <li><a class="global_gaNode" href="http://www.zealer.com/" data-galable="home_header_nav_index">首页</a></li>
                <li><a class="global_gaNode" href="http://www.zealer.com/media" data-galable="home_header_nav_media">视频</a></li>
                <li><a class="global_gaNode" href="http://tool.zealer.com/" data-galable="home_header_nav_phone">手机工具</a></li>
                <li><a class="global_gaNode" href="http://plus.zealer.com/" target="_blank" data-galable="home_header_nav_plus">社区</a></li>
                <li><a class="global_gaNode" href="http://fix.zealer.com/" target="_blank" data-galable="home_header_nav_fix">FIX</a></li>
                <li><a class="global_gaNode" href="http://lab.zealer.com/" target="_blank" data-galable="home_header_nav_lab">实验室</a></li>
                <li><a href="http://www.zealer.com/about?type=contect" class="header_contactUs global_gaNode" target="_blank" rel="nofollow" data-galable="home_header_nav_contact">联系我们</a></li>
                <li class="app_download">APP下载
                    <div class="app_area">
                        <div class="area_wrap clear">
                            <div class="area_left">
                                <div class="qr_wrap">
                                    <a href="http://www.zealer.com/assets/ZEALER.apk" target="_blank">立即下载安卓版</a>
                                </div>
                            </div>
                            <img class="area_right" src="{{asset('zealer_files/img_9c17cc22_phone.png')}}">
                        </div>
                    </div>
                </li>
            </ul>
            <div class="header_search clear">
                <input class="head_searchInput" placeholder="搜点什么...">
                <div class="index_icons head_searchIcon global_gaNode" data-type="video" data-galable="home_header_search"></div>
            </div>
        </div>

    </div>
</div>
<script id="showData.tpl" type="text/html">
    <div class="msg_content">
        <h2>欢迎你!</h2>
        <a href="http://www.zealer.com/user?pagetype=setbasic" class="msg_btn_box">
            <img src='' id="msg_pic"/>
        </a>
        <div id="msg_name"></div>
        你与极客之间的距离，可能只差个性<br />的头像！快去完善吧~
        <a href="http://www.zealer.com/user?pagetype=setbasic" class="msg_btn msg_btn_box">完善资料</a>
    </div>
</script>



<div class="global_mHeader">
    <div class="mHeader_menu"></div>
    <div class="mHeader_right">
        <a class="mHeader_login" href="http://www.zealer.com/login/?from=index&amp;redirect=http%3A%2F%2Fwww.zealer.com%2Fmedia%3Fcid%3D3%26index%3D8">登录</a>
        <a class="img_link clear" href="http://www.zealer.com/user?pagetype=setbasic">
            <img class="user_img" src="{{asset('zealer_files/mb_pic30.gif')}}" alt="会员头像">
        </a>
    </div>
    <ul class="mHeader_menuList">
        <li><a class="" href="http://www.zealer.com/">首页</a></li>
        <li><a class="" href="http://www.zealer.com/media">视频</a></li>
        <li><a class="" href="http://tool.zealer.com/">手机工具</a></li>
        <li><a class="" href="http://plus.zealer.com/" target="_blank">社区</a></li>
        <li><a class="" href="http://fix.zealer.com/" target="_blank">维修</a></li>
        <li><a class="" href="http://lab.zealer.com/" target="_blank">实验室</a></li>
        <li><a href="http://www.zealer.com/about?type=contect" class="header_contactUs" target="_blank" rel="nofollow">联系我们</a></li>
    </ul>
</div>

<div class="global_appDownload">
    <div class="appDownload_text">
        <div class="appDownload_icon"></div>
        <span class="text_title">ZEALER 手机客户端<span>
</span></span></div>
    <a href="http://a.app.qq.com/o/simple.jsp?pkgname=com.zealer.app" class="appDownload_btn">立即下载</a>
</div>

<div class="wrap">
    <div id="main">


        <div class="media_nav" style="top: 40px;">
            <div class="nav_wrap">
                <a href="http://www.zealer.com/media" class="media_nav_title"></a>
                <a href="http://www.zealer.com/media" style="display:none;">首页</a>
                @foreach($media as $m)
                <a class="media_btn" href="{{$m->media_url}}" cid="9">{{$m->media_name}}</a>
               @endforeach

                <span class="nav_arrow"></span>
            </div>
        </div>

@section('content')
    @show
            <div class="wrap_go" style="display: none;">
                <span></span>
                <a href="javascript:;">加载更多</a>
            </div>
    </div>
</div>
</div>


<div class="global_footer">
    <div class="footer_inner">
        <div class="inner_link clear">
            <dl>

                <p class="logo_footer index_icons"></p>
            </dl>
            <dl>
                <dt>业务</dt>
                <dd>
                    <a class="global_gaNode" data-galable="home_footer_nav_link" href="http://fix.zealer.com/" rel="nofollow">手机服务</a>
                    <a class="global_gaNode" data-galable="home_footer_nav_link" href="http://lab.zealer.com/" rel="nofollow">实验室</a>
                    <a class="global_gaNode" data-galable="home_footer_nav_link" href="http://plus.zealer.com/" rel="nofollow">社区</a>
                </dd>
            </dl>
            <dl>
                <dt>关于我们</dt>
                <dd>
                    <a class="global_gaNode" data-galable="home_footer_nav_link" href="http://www.zealer.com/about.html?type=item" rel="nofollow">会员条款</a>
                    <a class="global_gaNode" data-galable="home_footer_nav_link" href="http://www.zealer.com/about.html?type=join" rel="nofollow">加入我们</a>
                    <a class="global_gaNode" data-galable="home_footer_nav_link" href="http://www.zealer.com/about.html?type=about" rel="nofollow">关于 ZEALER</a>
                </dd>
            </dl>
            <dl class="footer_follow">
                <dt>关注我们</dt>
                <dd>
                    <a class="global_gaNode" data-galable="home_footer_nav_link" href="http://weibo.com/zealerchina" target="_blank" rel="nofollow">新浪微博</a>
                    <a class="global_gaNode" data-galable="home_footer_nav_link" href="http://www.zealer.com/about?type=contect" rel="nofollow">联系我们</a>
                </dd>
            </dl>
            <dl class="footer_wechat">
                <dt>官方微信</dt>
                <dd class="wechat_img"></dd>
            </dl>
            <dl class="footer_appDownload">
                <dt>APP 下载</dt>
                <dd class="app_img"></dd>
            </dl>
        </div>



        <div class="footer_message">
            <div class="footer_pcMsg clear">
                <div class="inner_copyr">
                    <img class="inner_lisense" src="{{asset('zealer_files/img_e90c7a45_global_footer_lisence.png')}}">
                    <span class="inner_no"><a class="global_gaNode" data-galable="home_footer_nav_link" href="http://www.miitbeian.gov.cn/" target="_blank" rel="nofollow">粤ICP备12076188号-1</a>&nbsp;</span>
                    <span class="inner_img">
<a class="global_gaNode" data-galable="home_footer_nav_link" href="http://szcert.ebs.org.cn/1d7f198a-09f0-4844-8212-07761b11dffe" target="_blank" rel="nofollow">
<img src="{{asset('zealer_files/newGovIcon.gif')}}" title="深圳市市场监督管理局企业主体身份公示" alt="深圳市市场监督管理局企业主体身份公示" width="80" height="33" border="0" style="border-width:0px;border:hidden; border:none;">
 </a>
</span>
                </div>
            </div>

            <div class="footer_mMsg">
                <div class="mMsg_slogen"></div>
                <div>© 2016 ZEALER | 粤ICP备12076188号-1 </div>
            </div>
        </div>
    </div>
</div>

<div class="side_btn">
    <span class="contect_btn"></span>
    <span class="to_up"></span>
</div>

<div class="bg_writer">
    <div class="content_writer">
        <p>我们十分重视您的体验感受</p>
        <p>请写下您的建议或者吐槽帮助我们更好的改进</p>
    </div>
</div>




<script src="{{asset('zealer_files/jquery-1.10.2.min.js')}}"></script>

<script src="{{asset('zealer_files/libs_46276.js')}}"></script>
<script src="{{asset('zealer_files/global_4eae39f142.js')}}"></script>
<script src="{{asset('zealer_files/stat.js')}}"></script>
<script src="{{asset('zealer_files/page_8aeee515cf.js')}}"></script>

<script>
    $(function(){

        Z.use('global/mediaHeader');Z.use('mediaFirst/mediaFirst');Z.use('media/page');Z.use('global/header');Z.use('footer/footer');
    });
</script>


<script type="text/javascript">
    var _hmt = _hmt || [];
    (function() {
        var hm = document.createElement("script");
        hm.src = "//hm.baidu.com/hm.js?93a776aa5a5632380561feba017dd90f";
        var s = document.getElementsByTagName("script")[0];
        s.parentNode.insertBefore(hm, s);
    })();
</script>
<script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
                (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
            m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-42162857-1', 'zealer.com');
    ga('send', 'pageview');
</script>
<script>
    // 百度推送， 上线请打开
    (function(){var bp = document.createElement('script');bp.src= '//push.zhanzhang.baidu.com/push.js';var s = document.getElementsByTagName("script")[0];s.parentNode.insertBefore(bp, s);})();
</script>


<div class="global_dialog"><div class="dialog_closebg"></div><div class="dialog_inner autoHeight contect_dialog" style="margin-left: -230px; margin-top: -110px; width: 460px; height: 220px;"><div class="dialog_content"><div class="user_reply" style="display: block;">
                <div class="bg_title">
                    <span style="width:13px; height:14px; background-position:0 -106px;" class="title_logo"></span>
                </div>
                <div class="bg_content">
                    <div class="contect_box">
                        <textarea class="content_contect">请输入您的反馈内容...</textarea>
                        <div>
                            <button class="contect_btn">提交</button>
                        </div>
                    </div>
                </div>
            </div></div></div></div><div style="position: static; width: 0px; height: 0px; border: none; padding: 0px; margin: 0px;"><div id="trans-tooltip"><div id="tip-left-top" style="background: url(&quot;chrome-extension://ikkbfngojljohpekonpldkamedehakni/imgs/map/tip-left-top.png&quot;);"></div><div id="tip-top" style="background: url(&quot;chrome-extension://ikkbfngojljohpekonpldkamedehakni/imgs/map/tip-top.png&quot;) repeat-x;"></div><div id="tip-right-top" style="background: url(&quot;chrome-extension://ikkbfngojljohpekonpldkamedehakni/imgs/map/tip-right-top.png&quot;);"></div><div id="tip-right" style="background: url(&quot;chrome-extension://ikkbfngojljohpekonpldkamedehakni/imgs/map/tip-right.png&quot;) repeat-y;"></div><div id="tip-right-bottom" style="background: url(&quot;chrome-extension://ikkbfngojljohpekonpldkamedehakni/imgs/map/tip-right-bottom.png&quot;);"></div><div id="tip-bottom" style="background: url(&quot;chrome-extension://ikkbfngojljohpekonpldkamedehakni/imgs/map/tip-bottom.png&quot;) repeat-x;"></div><div id="tip-left-bottom" style="background: url(&quot;chrome-extension://ikkbfngojljohpekonpldkamedehakni/imgs/map/tip-left-bottom.png&quot;);"></div><div id="tip-left" style="background: url(&quot;chrome-extension://ikkbfngojljohpekonpldkamedehakni/imgs/map/tip-left.png&quot;);"></div><div id="trans-content"></div></div><div id="tip-arrow-bottom" style="background: url(&quot;chrome-extension://ikkbfngojljohpekonpldkamedehakni/imgs/map/tip-arrow-bottom.png&quot;);"></div><div id="tip-arrow-top" style="background: url(&quot;chrome-extension://ikkbfngojljohpekonpldkamedehakni/imgs/map/tip-arrow-top.png&quot;);"></div></div></body></html>