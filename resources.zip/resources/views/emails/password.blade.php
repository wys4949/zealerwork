Click here to reset your password: {{ url('password/reset/'.$token) }}
